# Next Step

**CONDITIONAL GO.** Native proposer R1 passed, but the immediate PhiSpec
Top-30 Oracle produced 1.9333% blocking versus 1.7000% for proposer Top-1 and
1.8767% for KSP-FF K=50 hops.

Do not train a PhiSpec Ranker. First run a common-future Top-30 causal ceiling
on shared future request traces and measure candidate differences in block
count, first-block time, and blocked-request identity. Continue to Ranker
training only when that ceiling has non-zero blocking sensitivity and improves
over native proposer Top-1.
