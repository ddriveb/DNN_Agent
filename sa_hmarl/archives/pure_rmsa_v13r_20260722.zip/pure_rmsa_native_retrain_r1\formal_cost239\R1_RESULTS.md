# Pure-RMSA Native Proposer R1

| Method | Blocking | Expert Top-30 recall |
|---|---:|---:|
| ksp_ff_k50_hops | 1.8767% | 0.00% |
| ff_ksp_k50_hops | 5.6133% | 0.00% |
| native_proposer_top1 | 2.5200% | 100.00% |
| native_top30_phi_oracle | 1.8533% | 99.97% |

**R1 gate: PASS**

expert Top-30 recall >=95% and Top-1 blocking gap <=1.0 pp
