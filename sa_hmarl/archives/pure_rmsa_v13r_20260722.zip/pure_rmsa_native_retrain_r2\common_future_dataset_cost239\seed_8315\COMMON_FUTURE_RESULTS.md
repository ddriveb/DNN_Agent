# Pure-RMSA Native Common-Future Ceiling

Main trajectory blocking: 1.8167%
Groups: 60

| Continuation | H | Count sensitive | Identity sensitive | Oracle improved groups | Mean block improvement |
|---|---:|---:|---:|---:|---:|
| native_proposer_top1 | 20 | 18.33% | 18.33% | 1.67% | 0.0167 |
| native_proposer_top1 | 50 | 35.00% | 36.67% | 5.00% | 0.0500 |
| native_proposer_top1 | 100 | 58.33% | 61.67% | 15.00% | 0.1667 |
| ksp_ff_k50_hops | 20 | 20.00% | 20.00% | 1.67% | 0.0167 |
| ksp_ff_k50_hops | 50 | 33.33% | 36.67% | 1.67% | 0.0167 |
| ksp_ff_k50_hops | 100 | 56.67% | 65.00% | 15.00% | 0.1667 |

**Ranker gate: PASS**

At max H: non-zero block-count sensitivity, >=5% oracle-improved groups, positive mean oracle improvement
