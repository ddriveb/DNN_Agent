# Pure-RMSA Native Common-Future Ceiling

Main trajectory blocking: 2.3000%
Groups: 60

| Continuation | H | Count sensitive | Identity sensitive | Oracle improved groups | Mean block improvement |
|---|---:|---:|---:|---:|---:|
| native_proposer_top1 | 20 | 18.33% | 18.33% | 3.33% | 0.0333 |
| native_proposer_top1 | 50 | 41.67% | 48.33% | 10.00% | 0.1000 |
| native_proposer_top1 | 100 | 71.67% | 76.67% | 25.00% | 0.2667 |
| ksp_ff_k50_hops | 20 | 21.67% | 21.67% | 6.67% | 0.0667 |
| ksp_ff_k50_hops | 50 | 40.00% | 40.00% | 13.33% | 0.1333 |
| ksp_ff_k50_hops | 100 | 61.67% | 63.33% | 23.33% | 0.2500 |

**Ranker gate: PASS**

At max H: non-zero block-count sensitivity, >=5% oracle-improved groups, positive mean oracle improvement
