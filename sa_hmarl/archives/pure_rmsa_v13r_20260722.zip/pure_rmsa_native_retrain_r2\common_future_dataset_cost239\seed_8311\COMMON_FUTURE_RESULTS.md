# Pure-RMSA Native Common-Future Ceiling

Main trajectory blocking: 1.6000%
Groups: 60

| Continuation | H | Count sensitive | Identity sensitive | Oracle improved groups | Mean block improvement |
|---|---:|---:|---:|---:|---:|
| native_proposer_top1 | 20 | 8.33% | 8.33% | 0.00% | 0.0000 |
| native_proposer_top1 | 50 | 35.00% | 36.67% | 8.33% | 0.0833 |
| native_proposer_top1 | 100 | 51.67% | 56.67% | 28.33% | 0.2833 |
| ksp_ff_k50_hops | 20 | 8.33% | 8.33% | 0.00% | 0.0000 |
| ksp_ff_k50_hops | 50 | 40.00% | 40.00% | 5.00% | 0.0500 |
| ksp_ff_k50_hops | 100 | 56.67% | 58.33% | 13.33% | 0.1667 |

**Ranker gate: PASS**

At max H: non-zero block-count sensitivity, >=5% oracle-improved groups, positive mean oracle improvement
