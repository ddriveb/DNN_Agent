# Pure-RMSA Native Common-Future Ceiling

Main trajectory blocking: 1.8167%
Groups: 60

| Continuation | H | Count sensitive | Identity sensitive | Oracle improved groups | Mean block improvement |
|---|---:|---:|---:|---:|---:|
| native_proposer_top1 | 20 | 20.00% | 20.00% | 3.33% | 0.0333 |
| native_proposer_top1 | 50 | 45.00% | 45.00% | 10.00% | 0.1167 |
| native_proposer_top1 | 100 | 60.00% | 61.67% | 21.67% | 0.2500 |
| ksp_ff_k50_hops | 20 | 16.67% | 16.67% | 1.67% | 0.0167 |
| ksp_ff_k50_hops | 50 | 41.67% | 41.67% | 8.33% | 0.0833 |
| ksp_ff_k50_hops | 100 | 51.67% | 56.67% | 20.00% | 0.2333 |

**Ranker gate: PASS**

At max H: non-zero block-count sensitivity, >=5% oracle-improved groups, positive mean oracle improvement
