# Pure-RMSA v1.3-R K_path Ablation

Only topology-matched native checkpoints are used. No legacy SA-HMARL checkpoint is loaded.

| Topology | Method | K_path | Blocking | Decision ms | Proposal count |
|---|---|---:|---:|---:|---:|
| cost239 | ff_ksp | 5 | 0.0000% | 0.021 | 0.00 |
| cost239 | ff_ksp | 10 | 0.0000% | 0.044 | 0.00 |
| cost239 | ff_ksp | 20 | 0.0000% | 0.095 | 0.00 |
| cost239 | ff_ksp | 50 | 0.0000% | 0.246 | 0.00 |
| cost239 | ksp_ff | 5 | 0.0000% | 0.012 | 0.00 |
| cost239 | ksp_ff | 10 | 0.0000% | 0.013 | 0.00 |
| cost239 | ksp_ff | 20 | 0.0000% | 0.036 | 0.00 |
| cost239 | ksp_ff | 50 | 0.0000% | 0.026 | 0.00 |
| cost239 | native_afterstate_ranker_h20 | 5 | 0.0000% | 16.991 | 17.03 |
| cost239 | native_afterstate_ranker_h20 | 10 | 0.0000% | 23.752 | 28.13 |
| cost239 | native_afterstate_ranker_h20 | 20 | 0.0000% | 26.407 | 30.00 |
| cost239 | native_afterstate_ranker_h20 | 50 | 0.0000% | 31.628 | 30.00 |
| cost239 | native_proposer_top1 | 5 | 0.0000% | 1.537 | 8.23 |
| cost239 | native_proposer_top1 | 10 | 0.0000% | 2.461 | 13.60 |
| cost239 | native_proposer_top1 | 20 | 0.0000% | 2.761 | 23.63 |
| cost239 | native_proposer_top1 | 50 | 0.0000% | 3.788 | 30.00 |
| jpn48 | ff_ksp | 5 | 0.0000% | 0.043 | 0.00 |
| jpn48 | ff_ksp | 10 | 0.0000% | 0.085 | 0.00 |
| jpn48 | ff_ksp | 20 | 0.0000% | 0.115 | 0.00 |
| jpn48 | ff_ksp | 50 | 0.0000% | 0.285 | 0.00 |
| jpn48 | ksp_ff | 5 | 0.0000% | 0.016 | 0.00 |
| jpn48 | ksp_ff | 10 | 0.0000% | 0.017 | 0.00 |
| jpn48 | ksp_ff | 20 | 0.0000% | 0.049 | 0.00 |
| jpn48 | ksp_ff | 50 | 0.0000% | 0.034 | 0.00 |
| jpn48 | native_afterstate_ranker_h20 | 5 | 0.0000% | 46.738 | 25.57 |
| jpn48 | native_afterstate_ranker_h20 | 10 | 0.0000% | 43.949 | 28.83 |
| jpn48 | native_afterstate_ranker_h20 | 20 | 0.0000% | 44.480 | 29.53 |
| jpn48 | native_afterstate_ranker_h20 | 50 | 0.0000% | 45.339 | 30.00 |
| jpn48 | native_proposer_top1 | 5 | 0.0000% | 1.682 | 19.27 |
| jpn48 | native_proposer_top1 | 10 | 0.0000% | 1.795 | 27.63 |
| jpn48 | native_proposer_top1 | 20 | 0.0000% | 2.167 | 29.33 |
| jpn48 | native_proposer_top1 | 50 | 0.0000% | 7.254 | 30.00 |
| nsfnet | ff_ksp | 5 | 0.0000% | 0.026 | 0.00 |
| nsfnet | ff_ksp | 10 | 0.0000% | 0.045 | 0.00 |
| nsfnet | ff_ksp | 20 | 0.0000% | 0.068 | 0.00 |
| nsfnet | ff_ksp | 50 | 0.0000% | 0.188 | 0.00 |
| nsfnet | ksp_ff | 5 | 0.0000% | 0.016 | 0.00 |
| nsfnet | ksp_ff | 10 | 0.0000% | 0.014 | 0.00 |
| nsfnet | ksp_ff | 20 | 0.0000% | 0.023 | 0.00 |
| nsfnet | ksp_ff | 50 | 0.0000% | 0.023 | 0.00 |
| nsfnet | native_afterstate_ranker_h20 | 5 | 0.0000% | 15.497 | 19.20 |
| nsfnet | native_afterstate_ranker_h20 | 10 | 0.0000% | 19.587 | 26.13 |
| nsfnet | native_afterstate_ranker_h20 | 20 | 0.0000% | 25.245 | 28.33 |
| nsfnet | native_afterstate_ranker_h20 | 50 | 0.0000% | 28.089 | 28.30 |
| nsfnet | native_proposer_top1 | 5 | 0.0000% | 1.636 | 7.70 |
| nsfnet | native_proposer_top1 | 10 | 0.0000% | 1.921 | 12.90 |
| nsfnet | native_proposer_top1 | 20 | 0.0000% | 2.311 | 23.43 |
| nsfnet | native_proposer_top1 | 50 | 0.0000% | 3.661 | 30.00 |
| usnet | ff_ksp | 5 | 0.0000% | 0.035 | 0.00 |
| usnet | ff_ksp | 10 | 0.0000% | 0.096 | 0.00 |
| usnet | ff_ksp | 20 | 0.0000% | 0.161 | 0.00 |
| usnet | ff_ksp | 50 | 0.0000% | 0.266 | 0.00 |
| usnet | ksp_ff | 5 | 0.0000% | 0.016 | 0.00 |
| usnet | ksp_ff | 10 | 0.0000% | 0.020 | 0.00 |
| usnet | ksp_ff | 20 | 0.0000% | 0.023 | 0.00 |
| usnet | ksp_ff | 50 | 0.0000% | 0.027 | 0.00 |
| usnet | native_afterstate_ranker_h20 | 5 | 0.0000% | 31.817 | 25.00 |
| usnet | native_afterstate_ranker_h20 | 10 | 0.0000% | 35.078 | 29.30 |
| usnet | native_afterstate_ranker_h20 | 20 | 0.0000% | 37.419 | 30.00 |
| usnet | native_afterstate_ranker_h20 | 50 | 0.0000% | 40.006 | 30.00 |
| usnet | native_proposer_top1 | 5 | 0.0000% | 1.777 | 14.67 |
| usnet | native_proposer_top1 | 10 | 0.0000% | 1.966 | 24.77 |
| usnet | native_proposer_top1 | 20 | 0.0000% | 2.470 | 30.00 |
| usnet | native_proposer_top1 | 50 | 0.0000% | 3.640 | 30.00 |

## Mean across topologies

| Method | K_path | Blocking | Decision ms |
|---|---:|---:|---:|
| native_proposer_top1 | 5 | 0.0000% | 1.658 |
| native_proposer_top1 | 10 | 0.0000% | 2.036 |
| native_proposer_top1 | 20 | 0.0000% | 2.427 |
| native_proposer_top1 | 50 | 0.0000% | 4.586 |
| native_afterstate_ranker_h20 | 5 | 0.0000% | 27.761 |
| native_afterstate_ranker_h20 | 10 | 0.0000% | 30.592 |
| native_afterstate_ranker_h20 | 20 | 0.0000% | 33.388 |
| native_afterstate_ranker_h20 | 50 | 0.0000% | 36.265 |
| ksp_ff | 5 | 0.0000% | 0.015 |
| ksp_ff | 10 | 0.0000% | 0.016 |
| ksp_ff | 20 | 0.0000% | 0.033 |
| ksp_ff | 50 | 0.0000% | 0.027 |
| ff_ksp | 5 | 0.0000% | 0.032 |
| ff_ksp | 10 | 0.0000% | 0.067 |
| ff_ksp | 20 | 0.0000% | 0.110 |
| ff_ksp | 50 | 0.0000% | 0.246 |
