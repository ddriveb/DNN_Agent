# Pure-RMSA Native Common-Future Ceiling

Main trajectory blocking: 1.5000%
Groups: 60

| Continuation | H | Count sensitive | Identity sensitive | Oracle improved groups | Mean block improvement |
|---|---:|---:|---:|---:|---:|
| native_proposer_top1 | 20 | 15.00% | 15.00% | 0.00% | 0.0000 |
| native_proposer_top1 | 50 | 35.00% | 36.67% | 1.67% | 0.0167 |
| native_proposer_top1 | 100 | 60.00% | 63.33% | 10.00% | 0.1000 |
| ksp_ff_k50_hops | 20 | 11.67% | 11.67% | 0.00% | 0.0000 |
| ksp_ff_k50_hops | 50 | 38.33% | 40.00% | 5.00% | 0.0500 |
| ksp_ff_k50_hops | 100 | 51.67% | 56.67% | 10.00% | 0.1000 |

**Ranker gate: PASS**

At max H: non-zero block-count sensitivity, >=5% oracle-improved groups, positive mean oracle improvement
