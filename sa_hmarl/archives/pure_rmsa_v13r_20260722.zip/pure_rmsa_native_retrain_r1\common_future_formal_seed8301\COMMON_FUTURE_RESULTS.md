# Pure-RMSA Native Common-Future Ceiling

Main trajectory blocking: 1.6500%
Groups: 60

| Continuation | H | Count sensitive | Identity sensitive | Oracle improved groups | Mean block improvement |
|---|---:|---:|---:|---:|---:|
| native_proposer_top1 | 20 | 11.67% | 11.67% | 5.00% | 0.0500 |
| native_proposer_top1 | 50 | 23.33% | 23.33% | 8.33% | 0.0833 |
| native_proposer_top1 | 100 | 43.33% | 43.33% | 16.67% | 0.1667 |
| ksp_ff_k50_hops | 20 | 13.33% | 15.00% | 5.00% | 0.0500 |
| ksp_ff_k50_hops | 50 | 20.00% | 21.67% | 5.00% | 0.0667 |
| ksp_ff_k50_hops | 100 | 28.33% | 28.33% | 8.33% | 0.0833 |

**Ranker gate: PASS**

At max H: non-zero block-count sensitivity, >=5% oracle-improved groups, positive mean oracle improvement
