# Pure-RMSA Native Common-Future Ceiling

Main trajectory blocking: 1.2333%
Groups: 60

| Continuation | H | Count sensitive | Identity sensitive | Oracle improved groups | Mean block improvement |
|---|---:|---:|---:|---:|---:|
| native_proposer_top1 | 20 | 20.00% | 20.00% | 3.33% | 0.0333 |
| native_proposer_top1 | 50 | 43.33% | 45.00% | 3.33% | 0.0333 |
| native_proposer_top1 | 100 | 58.33% | 66.67% | 18.33% | 0.1833 |
| ksp_ff_k50_hops | 20 | 15.00% | 15.00% | 0.00% | 0.0000 |
| ksp_ff_k50_hops | 50 | 40.00% | 40.00% | 3.33% | 0.0333 |
| ksp_ff_k50_hops | 100 | 60.00% | 61.67% | 11.67% | 0.1167 |

**Ranker gate: PASS**

At max H: non-zero block-count sensitivity, >=5% oracle-improved groups, positive mean oracle improvement
