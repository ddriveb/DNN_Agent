# Pure-RMSA Native Common-Future Ceiling

Main trajectory blocking: 1.9167%
Groups: 60

| Continuation | H | Count sensitive | Identity sensitive | Oracle improved groups | Mean block improvement |
|---|---:|---:|---:|---:|---:|
| native_proposer_top1 | 20 | 18.33% | 20.00% | 1.67% | 0.0167 |
| native_proposer_top1 | 50 | 45.00% | 50.00% | 11.67% | 0.1167 |
| native_proposer_top1 | 100 | 68.33% | 73.33% | 23.33% | 0.3167 |
| ksp_ff_k50_hops | 20 | 18.33% | 20.00% | 0.00% | 0.0000 |
| ksp_ff_k50_hops | 50 | 43.33% | 46.67% | 6.67% | 0.0667 |
| ksp_ff_k50_hops | 100 | 58.33% | 61.67% | 11.67% | 0.1333 |

**Ranker gate: PASS**

At max H: non-zero block-count sensitivity, >=5% oracle-improved groups, positive mean oracle improvement
