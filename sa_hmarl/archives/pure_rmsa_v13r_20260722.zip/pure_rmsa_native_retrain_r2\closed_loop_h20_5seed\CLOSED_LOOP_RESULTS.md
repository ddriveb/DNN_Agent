# Pure-RMSA Native H20 Ranker Closed Loop

| Method | Blocking | Decision ms | Ranker disagreement |
|---|---:|---:|---:|
| ksp_ff_k50_hops | 1.8767% | 0.011 | 0.00% |
| native_proposer_top1 | 1.7000% | 2.450 | 0.00% |
| native_afterstate_ranker_h20 | 5.3100% | 10.972 | 62.91% |

Ranker - proposer: +3.6100 pp, 95% bootstrap CI [3.3066666666666675, 3.9833333333333334]
Ranker - KSP-FF: +3.4333 pp, 95% bootstrap CI [3.19, 3.743333333333333]
