# Pure-RMSA Native Common-Future Ceiling

Main trajectory blocking: 1.7833%
Groups: 60

| Continuation | H | Count sensitive | Identity sensitive | Oracle improved groups | Mean block improvement |
|---|---:|---:|---:|---:|---:|
| native_proposer_top1 | 20 | 16.67% | 16.67% | 0.00% | 0.0000 |
| native_proposer_top1 | 50 | 30.00% | 31.67% | 5.00% | 0.0500 |
| native_proposer_top1 | 100 | 51.67% | 53.33% | 13.33% | 0.1333 |
| ksp_ff_k50_hops | 20 | 18.33% | 20.00% | 0.00% | 0.0000 |
| ksp_ff_k50_hops | 50 | 36.67% | 40.00% | 8.33% | 0.0833 |
| ksp_ff_k50_hops | 100 | 61.67% | 65.00% | 11.67% | 0.1167 |

**Ranker gate: PASS**

At max H: non-zero block-count sensitivity, >=5% oracle-improved groups, positive mean oracle improvement
