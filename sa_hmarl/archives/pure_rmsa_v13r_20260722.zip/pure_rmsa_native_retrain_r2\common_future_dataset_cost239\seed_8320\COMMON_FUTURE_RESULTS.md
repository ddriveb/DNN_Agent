# Pure-RMSA Native Common-Future Ceiling

Main trajectory blocking: 1.3333%
Groups: 60

| Continuation | H | Count sensitive | Identity sensitive | Oracle improved groups | Mean block improvement |
|---|---:|---:|---:|---:|---:|
| native_proposer_top1 | 20 | 20.00% | 20.00% | 10.00% | 0.1000 |
| native_proposer_top1 | 50 | 40.00% | 40.00% | 13.33% | 0.1333 |
| native_proposer_top1 | 100 | 61.67% | 61.67% | 30.00% | 0.3833 |
| ksp_ff_k50_hops | 20 | 21.67% | 21.67% | 6.67% | 0.0667 |
| ksp_ff_k50_hops | 50 | 40.00% | 41.67% | 16.67% | 0.1667 |
| ksp_ff_k50_hops | 100 | 55.00% | 56.67% | 23.33% | 0.2333 |

**Ranker gate: PASS**

At max H: non-zero block-count sensitivity, >=5% oracle-improved groups, positive mean oracle improvement
