# Pure-RMSA Native Common-Future Ceiling

Main trajectory blocking: 1.6000%
Groups: 60

| Continuation | H | Count sensitive | Identity sensitive | Oracle improved groups | Mean block improvement |
|---|---:|---:|---:|---:|---:|
| native_proposer_top1 | 20 | 16.67% | 16.67% | 3.33% | 0.0333 |
| native_proposer_top1 | 50 | 41.67% | 45.00% | 8.33% | 0.0833 |
| native_proposer_top1 | 100 | 58.33% | 60.00% | 25.00% | 0.2667 |
| ksp_ff_k50_hops | 20 | 18.33% | 18.33% | 1.67% | 0.0167 |
| ksp_ff_k50_hops | 50 | 45.00% | 48.33% | 3.33% | 0.0333 |
| ksp_ff_k50_hops | 100 | 60.00% | 60.00% | 16.67% | 0.1667 |

**Ranker gate: PASS**

At max H: non-zero block-count sensitivity, >=5% oracle-improved groups, positive mean oracle improvement
