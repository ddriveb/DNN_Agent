# Next Step

GO: generate grouped native Ranker data using common-future labels.
