# Pure-RMSA v1.3-R K_path Ablation

Only topology-matched native checkpoints are used. No legacy SA-HMARL checkpoint is loaded.

| Topology | Method | K_path | Blocking | Decision ms | Proposal count |
|---|---|---:|---:|---:|---:|
| cost239 | ff_ksp | 5 | 4.6833% | 0.023 | 0.00 |
| cost239 | ff_ksp | 10 | 4.8667% | 0.035 | 0.00 |
| cost239 | ff_ksp | 20 | 5.5667% | 0.053 | 0.00 |
| cost239 | ff_ksp | 50 | 6.6833% | 0.109 | 0.00 |
| cost239 | ksp_ff | 5 | 2.6167% | 0.013 | 0.00 |
| cost239 | ksp_ff | 10 | 2.2167% | 0.014 | 0.00 |
| cost239 | ksp_ff | 20 | 2.1333% | 0.015 | 0.00 |
| cost239 | ksp_ff | 50 | 1.8500% | 0.018 | 0.00 |
| cost239 | native_afterstate_ranker_h20 | 5 | 6.5167% | 10.670 | 11.67 |
| cost239 | native_afterstate_ranker_h20 | 10 | 5.4000% | 10.737 | 11.29 |
| cost239 | native_afterstate_ranker_h20 | 20 | 5.6333% | 12.371 | 11.63 |
| cost239 | native_afterstate_ranker_h20 | 50 | 5.4333% | 16.177 | 11.54 |
| cost239 | native_proposer_top1 | 5 | 2.4833% | 1.525 | 11.84 |
| cost239 | native_proposer_top1 | 10 | 1.9833% | 1.759 | 13.41 |
| cost239 | native_proposer_top1 | 20 | 1.4333% | 2.185 | 15.28 |
| cost239 | native_proposer_top1 | 50 | 1.5833% | 3.467 | 17.09 |
| jpn48 | ff_ksp | 5 | 6.6667% | 0.038 | 0.00 |
| jpn48 | ff_ksp | 10 | 5.5000% | 0.072 | 0.00 |
| jpn48 | ff_ksp | 20 | 4.6000% | 0.127 | 0.00 |
| jpn48 | ff_ksp | 50 | 4.0333% | 0.275 | 0.00 |
| jpn48 | ksp_ff | 5 | 7.7667% | 0.016 | 0.00 |
| jpn48 | ksp_ff | 10 | 6.2333% | 0.018 | 0.00 |
| jpn48 | ksp_ff | 20 | 5.6667% | 0.021 | 0.00 |
| jpn48 | ksp_ff | 50 | 4.9667% | 0.028 | 0.00 |
| jpn48 | native_afterstate_ranker_h20 | 5 | 10.3000% | 42.244 | 18.96 |
| jpn48 | native_afterstate_ranker_h20 | 10 | 9.2500% | 46.291 | 20.95 |
| jpn48 | native_afterstate_ranker_h20 | 20 | 9.0833% | 48.427 | 21.94 |
| jpn48 | native_afterstate_ranker_h20 | 50 | 8.2500% | 51.793 | 23.34 |
| jpn48 | native_proposer_top1 | 5 | 6.6000% | 1.448 | 20.32 |
| jpn48 | native_proposer_top1 | 10 | 5.6667% | 1.638 | 22.97 |
| jpn48 | native_proposer_top1 | 20 | 4.3000% | 2.196 | 24.71 |
| jpn48 | native_proposer_top1 | 50 | 3.5500% | 3.622 | 26.13 |
| nsfnet | ff_ksp | 5 | 3.9500% | 0.021 | 0.00 |
| nsfnet | ff_ksp | 10 | 4.0000% | 0.032 | 0.00 |
| nsfnet | ff_ksp | 20 | 3.8833% | 0.053 | 0.00 |
| nsfnet | ff_ksp | 50 | 4.4500% | 0.105 | 0.00 |
| nsfnet | ksp_ff | 5 | 3.2333% | 0.011 | 0.00 |
| nsfnet | ksp_ff | 10 | 2.8833% | 0.012 | 0.00 |
| nsfnet | ksp_ff | 20 | 2.7333% | 0.014 | 0.00 |
| nsfnet | ksp_ff | 50 | 2.7833% | 0.018 | 0.00 |
| nsfnet | native_afterstate_ranker_h20 | 5 | 5.4667% | 8.259 | 10.34 |
| nsfnet | native_afterstate_ranker_h20 | 10 | 5.5167% | 9.246 | 11.04 |
| nsfnet | native_afterstate_ranker_h20 | 20 | 6.5833% | 10.522 | 10.82 |
| nsfnet | native_afterstate_ranker_h20 | 50 | 7.7833% | 14.589 | 11.10 |
| nsfnet | native_proposer_top1 | 5 | 2.5167% | 1.468 | 11.22 |
| nsfnet | native_proposer_top1 | 10 | 2.4167% | 1.602 | 12.76 |
| nsfnet | native_proposer_top1 | 20 | 2.1667% | 2.072 | 13.90 |
| nsfnet | native_proposer_top1 | 50 | 2.0667% | 3.350 | 15.36 |
| usnet | ff_ksp | 5 | 6.4667% | 0.029 | 0.00 |
| usnet | ff_ksp | 10 | 6.3167% | 0.053 | 0.00 |
| usnet | ff_ksp | 20 | 5.8833% | 0.085 | 0.00 |
| usnet | ff_ksp | 50 | 6.5833% | 0.172 | 0.00 |
| usnet | ksp_ff | 5 | 7.0333% | 0.014 | 0.00 |
| usnet | ksp_ff | 10 | 5.8833% | 0.018 | 0.00 |
| usnet | ksp_ff | 20 | 5.0833% | 0.020 | 0.00 |
| usnet | ksp_ff | 50 | 4.4500% | 0.025 | 0.00 |
| usnet | native_afterstate_ranker_h20 | 5 | 9.1167% | 21.337 | 16.09 |
| usnet | native_afterstate_ranker_h20 | 10 | 8.6000% | 23.385 | 17.05 |
| usnet | native_afterstate_ranker_h20 | 20 | 9.1000% | 25.471 | 17.05 |
| usnet | native_afterstate_ranker_h20 | 50 | 12.5500% | 26.886 | 14.35 |
| usnet | native_proposer_top1 | 5 | 5.9833% | 1.398 | 16.74 |
| usnet | native_proposer_top1 | 10 | 4.9000% | 1.649 | 18.74 |
| usnet | native_proposer_top1 | 20 | 4.2667% | 2.187 | 20.22 |
| usnet | native_proposer_top1 | 50 | 3.7167% | 3.469 | 20.88 |

## Mean across topologies

| Method | K_path | Blocking | Decision ms |
|---|---:|---:|---:|
| native_proposer_top1 | 5 | 4.3958% | 1.460 |
| native_proposer_top1 | 10 | 3.7417% | 1.662 |
| native_proposer_top1 | 20 | 3.0417% | 2.160 |
| native_proposer_top1 | 50 | 2.7292% | 3.477 |
| native_afterstate_ranker_h20 | 5 | 7.8500% | 20.628 |
| native_afterstate_ranker_h20 | 10 | 7.1917% | 22.415 |
| native_afterstate_ranker_h20 | 20 | 7.6000% | 24.198 |
| native_afterstate_ranker_h20 | 50 | 8.5042% | 27.362 |
| ksp_ff | 5 | 5.1625% | 0.014 |
| ksp_ff | 10 | 4.3042% | 0.015 |
| ksp_ff | 20 | 3.9042% | 0.018 |
| ksp_ff | 50 | 3.5125% | 0.022 |
| ff_ksp | 5 | 5.4417% | 0.028 |
| ff_ksp | 10 | 5.1708% | 0.048 |
| ff_ksp | 20 | 4.9833% | 0.080 |
| ff_ksp | 50 | 5.4375% | 0.165 |
