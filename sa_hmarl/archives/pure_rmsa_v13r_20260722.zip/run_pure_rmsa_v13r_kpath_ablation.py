"""K_path ablation for topology-matched Pure-RMSA v1.3-R components."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict, Sequence

import numpy as np
import torch

from sa_hmarl.baselines.rmsa_baselines import (
    ff_ksp_highest_mod_action,
    ksp_ff_highest_mod_action,
)
from sa_hmarl.evaluation.diagnose_pure_rmsa_native_common_future import (
    _candidate_feature_matrix,
    _load_agent,
    _ranked_legal,
)
from sa_hmarl.evaluation.eval_pure_rmsa_native_ranker import _load_ranker
from sa_hmarl.evaluation.pure_rmsa_paper_env import (
    PureRMSAPaperEnv,
    PureRMSARequest,
    generate_paper_requests,
)
from sa_hmarl.training.train_pure_rmsa_native_proposer import TOPOLOGIES


PROPOSER_CHECKPOINT = (
    "sa_hmarl/experiments/pure_rmsa_native_retrain_r1/formal_cost239_v2/"
    "native_proposer_best.pt"
)
RANKER_CHECKPOINT = (
    "sa_hmarl/experiments/pure_rmsa_native_retrain_r2/ranker_20seed_h20/"
    "native_ranker_best.pt"
)
K_PATH_VALUES = (5, 10, 20, 50)
METHODS = ("native_proposer_top1", "native_afterstate_ranker_h20", "ksp_ff", "ff_ksp")
LOADS = {"cost239": 600.0, "nsfnet": 250.0, "usnet": 550.0, "jpn48": 375.0}


def _sha256(path: str) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _trace_hash(requests: Sequence[PureRMSARequest]) -> str:
    raw = json.dumps([asdict(request) for request in requests], sort_keys=True).encode()
    return hashlib.sha256(raw).hexdigest()


def _run(job: Dict[str, Any]) -> Dict[str, Any]:
    os.environ.setdefault("OMP_NUM_THREADS", "1")
    os.environ.setdefault("MKL_NUM_THREADS", "1")
    torch.set_num_threads(1)
    agent = None
    ranker = ranker_checkpoint = None
    if job["method"].startswith("native_"):
        agent = _load_agent(PROPOSER_CHECKPOINT)
    if job["method"] == "native_afterstate_ranker_h20":
        ranker, ranker_checkpoint = _load_ranker(RANKER_CHECKPOINT)
    env = PureRMSAPaperEnv(
        TOPOLOGIES[job["topology"]], num_slots=100,
        k_paths=job["k_path"], max_blocks=10,
    )
    requests = generate_paper_requests(
        env.num_nodes, job["seed"], job["warmup"] + job["evaluated"], job["load"]
    )
    env.reset()
    total = blocked = accepted = disagreements = 0
    decision_times = []
    legal_sum = proposal_sum = path_idx_sum = hops_sum = start_sum = fs_sum = 0.0
    for index, request in enumerate(requests):
        env.advance_time(request.arrival_time)
        obs = env.build_observation(request)
        started = time.perf_counter()
        ranked = np.empty(0, dtype=np.int64)
        if job["method"] == "ksp_ff":
            action = ksp_ff_highest_mod_action(obs)
        elif job["method"] == "ff_ksp":
            action = ff_ksp_highest_mod_action(obs)
        else:
            ranked = _ranked_legal(agent, obs, 30)
            action = None if ranked.size == 0 else int(ranked[0])
            if job["method"] == "native_afterstate_ranker_h20" and ranked.size:
                features = _candidate_feature_matrix(env, request, ranked.tolist(), agent)
                mean = np.asarray(ranker_checkpoint["feature_mean"], dtype=np.float32)
                std = np.asarray(ranker_checkpoint["feature_std"], dtype=np.float32)
                normalized = (features - mean) / std
                with torch.no_grad():
                    scores = ranker(torch.as_tensor(normalized, dtype=torch.float32)).cpu().numpy()
                selected = int(np.argmax(scores))
                action = int(ranked[selected])
                if index >= job["warmup"]:
                    disagreements += int(selected != 0)
        decision_ms = (time.perf_counter() - started) * 1000.0
        result = {"success": False, "reason": "r_no_valid_action"}
        if action is not None:
            if not np.asarray(obs["agent_r_mask"], dtype=bool)[int(action)]:
                raise RuntimeError(f"{job['method']} selected illegal action {action}")
            result = env.step(int(action), obs, request)
            if not result["success"]:
                raise RuntimeError(f"Legal action failed: {result}")
        if index < job["warmup"]:
            continue
        total += 1
        decision_times.append(decision_ms)
        legal_sum += float(np.asarray(obs["agent_r_mask"], dtype=bool).sum())
        proposal_sum += float(ranked.size)
        if not result["success"]:
            blocked += 1
            continue
        accepted += 1
        path_idx_sum += float(result["path_idx"])
        hops_sum += float(result["path_hops"])
        start_sum += float(result["start_slot"])
        fs_sum += float(result["required_fs"])
    return {
        "topology": job["topology"], "load_erlang": job["load"], "seed": job["seed"],
        "method": job["method"], "K_path": job["k_path"], "requests": total,
        "accepted": accepted, "blocked": blocked, "blocking_rate": blocked / max(total, 1),
        "avg_decision_ms": float(np.mean(decision_times)),
        "p95_decision_ms": float(np.percentile(decision_times, 95)),
        "avg_legal_actions": legal_sum / max(total, 1),
        "avg_proposal_count": proposal_sum / max(total, 1),
        "ranker_disagreement_rate": disagreements / max(total, 1),
        "avg_path_idx": path_idx_sum / max(accepted, 1),
        "avg_path_hops": hops_sum / max(accepted, 1),
        "avg_start_slot": start_sum / max(accepted, 1),
        "avg_required_fs": fs_sum / max(accepted, 1),
        "trace_hash": _trace_hash(requests),
    }


def _aggregate(runs: Sequence[Dict[str, Any]]) -> list[Dict[str, Any]]:
    groups: Dict[tuple[str, str, int], list[Dict[str, Any]]] = {}
    for run in runs:
        groups.setdefault((run["topology"], run["method"], run["K_path"]), []).append(run)
    output = []
    for (topology, method, k_path), group in sorted(groups.items()):
        rates = [row["blocking_rate"] for row in group]
        output.append({
            "topology": topology, "method": method, "K_path": k_path, "seeds": len(group),
            "blocking_rate": float(np.mean(rates)),
            "blocking_std": float(np.std(rates, ddof=1)) if len(rates) > 1 else 0.0,
            "avg_decision_ms": float(np.mean([row["avg_decision_ms"] for row in group])),
            "avg_legal_actions": float(np.mean([row["avg_legal_actions"] for row in group])),
            "avg_proposal_count": float(np.mean([row["avg_proposal_count"] for row in group])),
            "ranker_disagreement_rate": float(np.mean([row["ranker_disagreement_rate"] for row in group])),
            "avg_path_idx": float(np.mean([row["avg_path_idx"] for row in group])),
            "avg_path_hops": float(np.mean([row["avg_path_hops"] for row in group])),
            "avg_start_slot": float(np.mean([row["avg_start_slot"] for row in group])),
            "avg_required_fs": float(np.mean([row["avg_required_fs"] for row in group])),
        })
    return output


def _write_csv(path: Path, rows: Sequence[Dict[str, Any]]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def _write_summary(path: Path, aggregate: Sequence[Dict[str, Any]]) -> None:
    lines = [
        "# Pure-RMSA v1.3-R K_path Ablation", "",
        "Only topology-matched native checkpoints are used. No legacy SA-HMARL checkpoint is loaded.", "",
        "| Topology | Method | K_path | Blocking | Decision ms | Proposal count |",
        "|---|---|---:|---:|---:|---:|",
    ]
    for row in aggregate:
        lines.append(
            f"| {row['topology']} | {row['method']} | {row['K_path']} | "
            f"{100*row['blocking_rate']:.4f}% | {row['avg_decision_ms']:.3f} | "
            f"{row['avg_proposal_count']:.2f} |"
        )
    lines.extend(["", "## Mean across topologies", "", "| Method | K_path | Blocking | Decision ms |", "|---|---:|---:|---:|"])
    for method in METHODS:
        for k_path in K_PATH_VALUES:
            subset = [row for row in aggregate if row["method"] == method and row["K_path"] == k_path]
            lines.append(
                f"| {method} | {k_path} | {100*np.mean([row['blocking_rate'] for row in subset]):.4f}% | "
                f"{np.mean([row['avg_decision_ms'] for row in subset]):.3f} |"
            )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", default="mnt/agents/output/native_k_path_ablation")
    parser.add_argument("--seeds", default="5001,5002,5003")
    parser.add_argument("--warmup", type=int, default=500)
    parser.add_argument("--evaluated", type=int, default=2000)
    parser.add_argument("--workers", type=int, default=8)
    args = parser.parse_args()
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    seeds = [int(value) for value in args.seeds.split(",")]
    jobs = [{
        "topology": topology, "load": load, "seed": seed, "method": method,
        "k_path": k_path, "warmup": args.warmup, "evaluated": args.evaluated,
    } for topology, load in LOADS.items() for seed in seeds for k_path in K_PATH_VALUES for method in METHODS]
    started = time.time()
    runs = []
    with ProcessPoolExecutor(max_workers=max(1, args.workers)) as executor:
        futures = [executor.submit(_run, job) for job in jobs]
        for future in as_completed(futures):
            run = future.result()
            runs.append(run)
            print(json.dumps(run), flush=True)
    runs.sort(key=lambda row: (row["topology"], row["seed"], row["K_path"], row["method"]))
    for topology in LOADS:
        for seed in seeds:
            hashes = {row["trace_hash"] for row in runs if row["topology"] == topology and row["seed"] == seed}
            if len(hashes) != 1:
                raise RuntimeError(f"Trace mismatch for {topology} seed {seed}: {hashes}")
    aggregate = _aggregate(runs)
    _write_csv(output / "results.csv", runs)
    _write_csv(output / "aggregate.csv", aggregate)
    _write_summary(output / "summary.md", aggregate)
    (output / "manifest.json").write_text(json.dumps({
        "protocol": "topology-matched Pure-RMSA v1.3-R K_path ablation",
        "K_path_values": list(K_PATH_VALUES), "path_order": "hops_then_km",
        "proposal_top_k": 30, "slots": 100, "max_blocks": 10, "loads": LOADS,
        "proposer_checkpoint": PROPOSER_CHECKPOINT,
        "proposer_sha256": _sha256(PROPOSER_CHECKPOINT),
        "ranker_checkpoint": RANKER_CHECKPOINT,
        "ranker_sha256": _sha256(RANKER_CHECKPOINT),
        "legacy_checkpoint_loaded": False, "args": vars(args),
        "elapsed_seconds": time.time() - started,
    }, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
