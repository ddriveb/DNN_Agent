# Native Retraining Morning Summary

## What was trained

A fresh pure-RMSA masked Agent-R actor was initialized from scratch. It did
not load the legacy PPO-R or Strict v1.3 Ranker. Training used 2,920 legal
states from seeds 8101-8102 and a multi-positive objective over canonical
KSP-FF and FF-KSP actions. Validation used 500 separate states from seed 8201.

This is the **R1 supervised proposer warm start**, not yet the final
Pure-RMSA v1.3-R Ranker and not yet a PPO fine-tuning claim.

## Five-seed COST239 result

Protocol: 100 slots, load 600 Erlang, K=50 hops, four modulations, ten
start-ascending blocks, warmup 500, 6,000 evaluated requests per seed.

| Method | Mean blocking | Delta vs KSP-FF |
|---|---:|---:|
| KSP-FF K=50 hops | 1.8767% | - |
| FF-KSP K=50 hops | 5.6133% | +3.7366 pp |
| Native proposer Top-1 | **1.7000%** | **-0.1767 pp** |
| Native Top-30 immediate-PhiSpec Oracle | 1.9333% | +0.0566 pp |

Native proposer Top-1 had fewer blocks than KSP-FF on all five seeds. Its
held-out expert Top-30 recall was 100%, and online Top-30 recall was 100%.

## Interpretation

The frozen Strict v1.3 transfer failure was primarily an adaptation problem:
after native pure-RMSA retraining, the proposer moved from roughly 18.97%
blocking to 1.70% under the same paper-parity COST239 regime.

The immediate PhiSpec Oracle is not a valid next training target here. It
worsened blocking despite having access to all Top-30 candidates. The next
useful test is a common-future blocking oracle, not a PhiSpec Ranker.

## Next experiment

1. Sample uniform, pressure, and pre-block states from the new proposer
   trajectory.
2. For every Top-30 candidate, use the same future request trace and horizons
   H=20/50/100.
3. Measure block count, discounted blocks, first-block time, and blocked
   request identity before composing any scalar label.
4. Train a fresh pure-RMSA Ranker only if candidate-level blocking sensitivity
   is non-zero and the oracle beats proposer Top-1.
5. After COST239 passes, train one mixed-topology proposer/Ranker and evaluate
   NSFNET, USNET, and JPN48 on held-out seeds and locked loads.
