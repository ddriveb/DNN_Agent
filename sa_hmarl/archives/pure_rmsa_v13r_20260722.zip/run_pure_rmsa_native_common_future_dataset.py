"""Run independent common-future dataset shards with bounded concurrency."""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Dict


def _atomic_json(path: Path, payload: Dict[str, Any]) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    os.replace(tmp, path)


def _run_seed(args: argparse.Namespace, seed: int, root: Path) -> Dict[str, Any]:
    output = root / f"seed_{seed}"
    output.mkdir(parents=True, exist_ok=True)
    stdout_path = output / "stdout.log"
    stderr_path = output / "stderr.log"
    command = [
        sys.executable, "-m", "sa_hmarl.evaluation.diagnose_pure_rmsa_native_common_future",
        "--checkpoint", args.checkpoint,
        "--output-dir", str(output),
        "--topology", args.topology,
        "--load-erlang", str(args.load_erlang),
        "--seed", str(seed),
        "--warmup", str(args.warmup),
        "--evaluated", str(args.evaluated),
        "--groups-per-stratum", str(args.groups_per_stratum),
        "--min-candidates", str(args.min_candidates),
        "--horizons", args.horizons,
        "--workers", str(args.workers_per_seed),
    ]
    started = time.time()
    with stdout_path.open("w", encoding="utf-8") as stdout, stderr_path.open("w", encoding="utf-8") as stderr:
        completed = subprocess.run(command, stdout=stdout, stderr=stderr, check=False)
    return {
        "seed": seed, "returncode": completed.returncode,
        "elapsed_seconds": time.time() - started,
        "output_dir": str(output), "command": command,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--output-root", required=True)
    parser.add_argument("--seeds", default="8301,8302,8303,8304,8305,8306,8307,8308")
    parser.add_argument("--topology", default="cost239")
    parser.add_argument("--load-erlang", type=float, default=600.0)
    parser.add_argument("--warmup", type=int, default=500)
    parser.add_argument("--evaluated", type=int, default=6000)
    parser.add_argument("--groups-per-stratum", type=int, default=20)
    parser.add_argument("--min-candidates", type=int, default=5)
    parser.add_argument("--horizons", default="20,50,100")
    parser.add_argument("--max-concurrent-seeds", type=int, default=2)
    parser.add_argument("--workers-per-seed", type=int, default=4)
    args = parser.parse_args()

    root = Path(args.output_root)
    root.mkdir(parents=True, exist_ok=True)
    seeds = [int(x) for x in args.seeds.split(",")]
    status: Dict[str, Any] = {"stage": "running", "started": time.time(), "args": vars(args), "runs": []}
    _atomic_json(root / "DATASET_RUN_STATUS.json", status)
    with ThreadPoolExecutor(max_workers=max(1, args.max_concurrent_seeds)) as executor:
        futures = {executor.submit(_run_seed, args, seed, root): seed for seed in seeds}
        for future in as_completed(futures):
            run = future.result()
            status["runs"].append(run)
            status["runs"].sort(key=lambda item: item["seed"])
            _atomic_json(root / "DATASET_RUN_STATUS.json", status)
            print(json.dumps(run), flush=True)
    failures = [run for run in status["runs"] if run["returncode"] != 0]
    status.update({
        "stage": "failed" if failures else "complete",
        "completed": time.time(), "failed_seeds": [run["seed"] for run in failures],
    })
    _atomic_json(root / "DATASET_RUN_STATUS.json", status)
    if failures:
        raise SystemExit(f"Dataset shards failed: {status['failed_seeds']}")


if __name__ == "__main__":
    main()
