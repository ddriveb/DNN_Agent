# Expanded 20-Seed Afterstate Ranker Decision

## Decision

**STOP the current all-state afterstate Ranker. Keep the native proposer
Top-1 as the best verified method.**

## Data and offline training

- 20 seeds, 1,200 common-future request groups.
- 16 training seeds, 2 validation seeds, 2 unopened test seeds.
- 28 pure-RMSA pre/action/exact-afterstate features.
- No legacy PPO-R or Ranker checkpoint was loaded.
- Mean H100 block-count sensitivity: 60.83%.
- Mean H100 Oracle-improved group ratio: 21.58%.
- Mean H100 Oracle improvement: 0.2442 future blocks per group.

H20 was selected using validation regret only:

| Horizon | Validation model/deployed regret | Test model/deployed regret |
|---:|---:|---:|
| 20 | 0.0333 / 0.0417 | 0.0250 / 0.0500 |
| 50 | 0.0417 / 0.0750 | 0.1083 / 0.1167 |
| 100 | 0.1750 / 0.2000 | 0.3000 / 0.3000 |

The H20 model therefore passed the pre-registered offline gate.

## Five-seed closed loop

Protocol: COST239, 100 slots, 600 Erlang, K=50 hops, four modulations,
ten start-ascending blocks, warmup 500, 6,000 evaluated requests per seed.

| Method | Blocking | Selector decision time | Ranker disagreement |
|---|---:|---:|---:|
| KSP-FF K=50 hops | 1.8767% | 0.011 ms | - |
| Native proposer Top-1 | **1.7000%** | 2.450 ms | - |
| Native proposer Top-30 + H20 afterstate Ranker | 5.3100% | 10.972 ms | 62.91% |

- Ranker minus proposer: **+3.6100 pp**.
- Bootstrap 95% CI: **[+3.3067, +3.9833] pp**.
- Ranker was worse on all five paired seeds.
- Ranker also selected longer paths and larger FS demand on average.

## What is proven

1. The native proposer retraining is effective: 1.7000% versus KSP-FF
   1.8767% in the five-seed pilot.
2. The proposer Top-30 contains actions with a real single-intervention
   common-future blocking ceiling.
3. The current 28-D Ranker can reduce offline regret on held-out static groups.
4. The current all-state online Ranker does not convert that offline result
   into closed-loop improvement and substantially worsens blocking.

## Likely mechanism, not yet causally proven

Each training label changes one current action and then uses the native
proposer as the future continuation. Online deployment instead invokes the
Ranker again at every later request. With 62.91% action disagreement, this
creates a trajectory distribution far from the proposer-generated training
states. The observed failure is consistent with compounding off-policy
covariate shift.

## Required protocol for any continuation

Do not add more static proposer-trajectory groups and do not tune an online
confidence threshold on the five evaluation seeds. A valid next attempt must:

1. deploy the current Ranker on separate training seeds;
2. collect the states it actually visits;
3. relabel those states with common futures using the current deployed policy
   as continuation;
4. retrain and repeat as a fixed, limited DAgger/on-policy iteration;
5. use new validation and test seeds before another closed-loop claim.

Until that protocol is approved and passes, the paper-facing result remains
the native proposer Top-1, not the afterstate Ranker.
