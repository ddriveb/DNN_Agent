# Pure-RMSA Native Common-Future Ceiling

Main trajectory blocking: 1.6500%
Groups: 60

| Continuation | H | Count sensitive | Identity sensitive | Oracle improved groups | Mean block improvement |
|---|---:|---:|---:|---:|---:|
| native_proposer_top1 | 20 | 18.33% | 18.33% | 8.33% | 0.0833 |
| native_proposer_top1 | 50 | 40.00% | 41.67% | 15.00% | 0.1500 |
| native_proposer_top1 | 100 | 61.67% | 63.33% | 21.67% | 0.2667 |
| ksp_ff_k50_hops | 20 | 25.00% | 25.00% | 6.67% | 0.0667 |
| ksp_ff_k50_hops | 50 | 41.67% | 41.67% | 11.67% | 0.1167 |
| ksp_ff_k50_hops | 100 | 60.00% | 61.67% | 18.33% | 0.2000 |

**Ranker gate: PASS**

At max H: non-zero block-count sensitivity, >=5% oracle-improved groups, positive mean oracle improvement
