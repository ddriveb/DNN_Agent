# Pure-RMSA Native Ranker Training

Selected epoch: 1

| Split | Groups | Sensitive | Model count regret | Deployed count regret | Best hit |
|---|---:|---:|---:|---:|---:|
| train | 360 | 229 | 0.2528 | 0.2583 | 77.78% |
| validation | 60 | 38 | 0.1333 | 0.1000 | 86.67% |
| test | 60 | 32 | 0.1667 | 0.1333 | 85.00% |
