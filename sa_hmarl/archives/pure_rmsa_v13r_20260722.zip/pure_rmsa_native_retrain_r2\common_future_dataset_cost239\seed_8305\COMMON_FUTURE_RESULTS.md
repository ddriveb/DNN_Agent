# Pure-RMSA Native Common-Future Ceiling

Main trajectory blocking: 2.3333%
Groups: 60

| Continuation | H | Count sensitive | Identity sensitive | Oracle improved groups | Mean block improvement |
|---|---:|---:|---:|---:|---:|
| native_proposer_top1 | 20 | 13.33% | 13.33% | 0.00% | 0.0000 |
| native_proposer_top1 | 50 | 26.67% | 30.00% | 5.00% | 0.0833 |
| native_proposer_top1 | 100 | 56.67% | 60.00% | 26.67% | 0.3500 |
| ksp_ff_k50_hops | 20 | 11.67% | 11.67% | 1.67% | 0.0167 |
| ksp_ff_k50_hops | 50 | 30.00% | 30.00% | 8.33% | 0.1000 |
| ksp_ff_k50_hops | 100 | 56.67% | 56.67% | 15.00% | 0.1833 |

**Ranker gate: PASS**

At max H: non-zero block-count sensitivity, >=5% oracle-improved groups, positive mean oracle improvement
