# Pure-RMSA Native Common-Future Ceiling

Main trajectory blocking: 1.9500%
Groups: 60

| Continuation | H | Count sensitive | Identity sensitive | Oracle improved groups | Mean block improvement |
|---|---:|---:|---:|---:|---:|
| native_proposer_top1 | 20 | 33.33% | 33.33% | 3.33% | 0.0333 |
| native_proposer_top1 | 50 | 48.33% | 51.67% | 5.00% | 0.0500 |
| native_proposer_top1 | 100 | 61.67% | 66.67% | 21.67% | 0.2500 |
| ksp_ff_k50_hops | 20 | 28.33% | 28.33% | 1.67% | 0.0167 |
| ksp_ff_k50_hops | 50 | 48.33% | 48.33% | 5.00% | 0.0500 |
| ksp_ff_k50_hops | 100 | 58.33% | 61.67% | 8.33% | 0.0833 |

**Ranker gate: PASS**

At max H: non-zero block-count sensitivity, >=5% oracle-improved groups, positive mean oracle improvement
