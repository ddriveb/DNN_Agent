# Pure-RMSA Native Ranker Training

Selected epoch: 1

| Split | Groups | Sensitive | Model count regret | Deployed count regret | Best hit |
|---|---:|---:|---:|---:|---:|
| train | 960 | 612 | 0.2354 | 0.2427 | 79.27% |
| validation | 120 | 81 | 0.1750 | 0.2000 | 82.50% |
| test | 120 | 78 | 0.3000 | 0.3000 | 75.83% |
