# Pure-RMSA Native Proposer R1

| Method | Blocking | Expert Top-30 recall |
|---|---:|---:|
| ksp_ff_k50_hops | 0.0000% | 0.00% |
| ff_ksp_k50_hops | 1.2000% | 0.00% |
| native_proposer_top1 | 0.0000% | 100.00% |
| native_top30_phi_oracle | 0.0000% | 99.80% |

**R1 gate: PASS**

expert Top-30 recall >=95% and Top-1 blocking gap <=1.0 pp
