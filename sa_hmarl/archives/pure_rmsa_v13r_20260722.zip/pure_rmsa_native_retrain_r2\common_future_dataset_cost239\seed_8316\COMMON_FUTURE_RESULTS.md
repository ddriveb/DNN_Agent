# Pure-RMSA Native Common-Future Ceiling

Main trajectory blocking: 1.1833%
Groups: 60

| Continuation | H | Count sensitive | Identity sensitive | Oracle improved groups | Mean block improvement |
|---|---:|---:|---:|---:|---:|
| native_proposer_top1 | 20 | 18.33% | 18.33% | 6.67% | 0.0667 |
| native_proposer_top1 | 50 | 43.33% | 45.00% | 15.00% | 0.1500 |
| native_proposer_top1 | 100 | 61.67% | 63.33% | 30.00% | 0.3000 |
| ksp_ff_k50_hops | 20 | 15.00% | 15.00% | 5.00% | 0.0500 |
| ksp_ff_k50_hops | 50 | 35.00% | 35.00% | 11.67% | 0.1167 |
| ksp_ff_k50_hops | 100 | 66.67% | 66.67% | 15.00% | 0.1667 |

**Ranker gate: PASS**

At max H: non-zero block-count sensitivity, >=5% oracle-improved groups, positive mean oracle improvement
