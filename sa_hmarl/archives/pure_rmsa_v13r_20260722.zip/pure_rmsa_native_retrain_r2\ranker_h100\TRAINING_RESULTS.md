# Pure-RMSA Native Ranker Training

Selected epoch: 3

| Split | Groups | Sensitive | Model count regret | Deployed count regret | Best hit |
|---|---:|---:|---:|---:|---:|
| train | 360 | 229 | 0.2389 | 0.2583 | 80.00% |
| validation | 60 | 38 | 0.0667 | 0.1000 | 93.33% |
| test | 60 | 32 | 0.1333 | 0.1333 | 86.67% |
