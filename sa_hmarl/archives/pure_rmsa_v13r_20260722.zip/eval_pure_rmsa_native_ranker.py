"""Paired closed-loop pilot for the native pure-RMSA afterstate Ranker."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict, Optional, Sequence, Tuple

import numpy as np
import torch

from sa_hmarl.baselines.rmsa_baselines import ksp_ff_highest_mod_action
from sa_hmarl.evaluation.diagnose_pure_rmsa_native_common_future import (
    FEATURE_NAMES,
    _candidate_feature_matrix,
    _load_agent,
    _ranked_legal,
)
from sa_hmarl.evaluation.pure_rmsa_paper_env import (
    PureRMSAPaperEnv,
    PureRMSARequest,
    generate_paper_requests,
)
from sa_hmarl.training.train_pure_rmsa_native_proposer import TOPOLOGIES
from sa_hmarl.training.train_pure_rmsa_native_ranker import NativeRMSARanker


METHODS = ("ksp_ff_k50_hops", "native_proposer_top1", "native_afterstate_ranker_h20")


def _trace_hash(requests: Sequence[PureRMSARequest]) -> str:
    raw = json.dumps([asdict(req) for req in requests], sort_keys=True).encode()
    return hashlib.sha256(raw).hexdigest()


def _load_ranker(path: str) -> Tuple[NativeRMSARanker, Dict[str, Any]]:
    checkpoint = torch.load(path, map_location="cpu", weights_only=False)
    if list(checkpoint["feature_names"]) != list(FEATURE_NAMES):
        raise RuntimeError("Online Ranker feature schema differs from training schema")
    if int(checkpoint["horizon"]) != 20:
        raise RuntimeError(f"Formal online pilot is locked to H20, got H={checkpoint['horizon']}")
    model = NativeRMSARanker(
        int(checkpoint["input_dim"]), tuple(checkpoint.get("hidden_dims", (128, 64)))
    )
    model.load_state_dict(checkpoint["model_state"])
    model.eval()
    return model, checkpoint


def _decode(action: int, num_mods: int, max_blocks: int) -> Tuple[int, int, int]:
    path_idx = int(action) // (num_mods * max_blocks)
    rem = int(action) % (num_mods * max_blocks)
    mod_idx, block_idx = divmod(rem, max_blocks)
    return path_idx, mod_idx, block_idx


def _run(job: Dict[str, Any]) -> Dict[str, Any]:
    os.environ.setdefault("OMP_NUM_THREADS", "1")
    os.environ.setdefault("MKL_NUM_THREADS", "1")
    torch.set_num_threads(1)
    agent = _load_agent(job["proposer_checkpoint"])
    ranker = ranker_checkpoint = None
    if job["method"] == "native_afterstate_ranker_h20":
        ranker, ranker_checkpoint = _load_ranker(job["ranker_checkpoint"])
    env = PureRMSAPaperEnv(TOPOLOGIES[job["topology"]], num_slots=100, k_paths=50, max_blocks=10)
    requests = generate_paper_requests(
        env.num_nodes, job["seed"], job["warmup"] + job["evaluated"], job["load"]
    )
    env.reset()
    blocked = total = disagreements = 0
    decision_times = []
    sums = {"path_hops": 0.0, "path_km": 0.0, "required_fs": 0.0, "start_slot": 0.0}
    accepted = 0
    for index, request in enumerate(requests):
        env.advance_time(request.arrival_time)
        obs = env.build_observation(request)
        started = time.perf_counter()
        ranked = None
        if job["method"] == "ksp_ff_k50_hops":
            raw_action = ksp_ff_highest_mod_action(obs)
            action = None if raw_action is None else int(raw_action)
        else:
            ranked = _ranked_legal(agent, obs, 30)
            action = None if ranked.size == 0 else int(ranked[0])
            if job["method"] == "native_afterstate_ranker_h20" and ranked.size:
                features = _candidate_feature_matrix(env, request, ranked.tolist(), agent)
                mean = np.asarray(ranker_checkpoint["feature_mean"], dtype=np.float32)
                std = np.asarray(ranker_checkpoint["feature_std"], dtype=np.float32)
                normalized = (features - mean) / std
                with torch.no_grad():
                    scores = ranker(torch.as_tensor(normalized, dtype=torch.float32)).cpu().numpy()
                selected = int(np.argmax(scores))
                action = int(ranked[selected])
                if index >= job["warmup"]:
                    disagreements += int(selected != 0)
        decision_ms = (time.perf_counter() - started) * 1000.0
        result = {"success": False, "reason": "r_no_valid_action"}
        if action is not None:
            result = env.step(action, obs, request)
        if index >= job["warmup"]:
            total += 1
            blocked += int(not result["success"])
            decision_times.append(decision_ms)
            if result["success"]:
                accepted += 1
                for key in sums:
                    sums[key] += float(result[key])
    return {
        "topology": job["topology"], "load_erlang": job["load"],
        "seed": job["seed"], "method": job["method"],
        "requests": total, "blocked": blocked, "blocking_rate": blocked / max(total, 1),
        "accepted": accepted, "ranker_disagreement_rate": disagreements / max(total, 1),
        "avg_decision_ms": float(np.mean(decision_times)),
        "p95_decision_ms": float(np.percentile(decision_times, 95)),
        **{f"avg_{key}": value / max(accepted, 1) for key, value in sums.items()},
        "trace_hash": _trace_hash(requests),
    }


def _bootstrap_ci(values: Sequence[float], seed: int = 42) -> Tuple[float, float]:
    values = np.asarray(values, dtype=float)
    rng = np.random.RandomState(seed)
    means = np.asarray([rng.choice(values, len(values), replace=True).mean() for _ in range(10000)])
    return float(np.percentile(means, 2.5)), float(np.percentile(means, 97.5))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--proposer-checkpoint", required=True)
    parser.add_argument("--ranker-checkpoint", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--topology", default="cost239", choices=sorted(TOPOLOGIES))
    parser.add_argument("--load-erlang", type=float, default=600.0)
    parser.add_argument("--seeds", default="5001,5002,5003,5004,5005")
    parser.add_argument("--warmup", type=int, default=500)
    parser.add_argument("--evaluated", type=int, default=6000)
    parser.add_argument("--workers", type=int, default=3)
    args = parser.parse_args()

    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    seeds = [int(x) for x in args.seeds.split(",")]
    jobs = [{
        "proposer_checkpoint": args.proposer_checkpoint,
        "ranker_checkpoint": args.ranker_checkpoint,
        "topology": args.topology, "load": args.load_erlang,
        "seed": seed, "method": method, "warmup": args.warmup, "evaluated": args.evaluated,
    } for seed in seeds for method in METHODS]
    started = time.time()
    runs = []
    with ProcessPoolExecutor(max_workers=max(1, args.workers)) as executor:
        futures = [executor.submit(_run, job) for job in jobs]
        for future in as_completed(futures):
            run = future.result()
            runs.append(run)
            print(json.dumps(run), flush=True)
    runs.sort(key=lambda run: (run["seed"], run["method"]))
    for seed in seeds:
        hashes = {run["trace_hash"] for run in runs if run["seed"] == seed}
        if len(hashes) != 1:
            raise RuntimeError(f"Request trace mismatch for seed {seed}: {hashes}")
    aggregate: Dict[str, Any] = {}
    for method in METHODS:
        subset = [run for run in runs if run["method"] == method]
        aggregate[method] = {
            "blocking_mean": float(np.mean([run["blocking_rate"] for run in subset])),
            "blocking_per_seed": [run["blocking_rate"] for run in subset],
            "avg_decision_ms": float(np.mean([run["avg_decision_ms"] for run in subset])),
            "ranker_disagreement_rate": float(np.mean([run["ranker_disagreement_rate"] for run in subset])),
        }
    ranker_delta = np.asarray(aggregate["native_afterstate_ranker_h20"]["blocking_per_seed"]) - np.asarray(
        aggregate["native_proposer_top1"]["blocking_per_seed"]
    )
    ksp_delta = np.asarray(aggregate["native_afterstate_ranker_h20"]["blocking_per_seed"]) - np.asarray(
        aggregate["ksp_ff_k50_hops"]["blocking_per_seed"]
    )
    result = {
        "protocol": "pure_rmsa_native_ranker_h20_closed_loop_pilot",
        "elapsed_seconds": time.time() - started, "runs": runs, "aggregate": aggregate,
        "paired": {
            "ranker_minus_proposer_pp": float(100 * ranker_delta.mean()),
            "ranker_minus_proposer_ci95_pp": [100 * x for x in _bootstrap_ci(ranker_delta)],
            "ranker_wins_vs_proposer": int((ranker_delta < 0).sum()),
            "ranker_minus_ksp_pp": float(100 * ksp_delta.mean()),
            "ranker_minus_ksp_ci95_pp": [100 * x for x in _bootstrap_ci(ksp_delta)],
            "ranker_wins_vs_ksp": int((ksp_delta < 0).sum()),
        },
    }
    tmp = output / "CLOSED_LOOP_RESULTS.json.tmp"
    tmp.write_text(json.dumps(result, indent=2), encoding="utf-8")
    os.replace(tmp, output / "CLOSED_LOOP_RESULTS.json")
    lines = [
        "# Pure-RMSA Native H20 Ranker Closed Loop", "",
        "| Method | Blocking | Decision ms | Ranker disagreement |",
        "|---|---:|---:|---:|",
    ]
    for method in METHODS:
        row = aggregate[method]
        lines.append(
            f"| {method} | {100*row['blocking_mean']:.4f}% | {row['avg_decision_ms']:.3f} | "
            f"{100*row['ranker_disagreement_rate']:.2f}% |"
        )
    lines.extend([
        "", f"Ranker - proposer: {result['paired']['ranker_minus_proposer_pp']:+.4f} pp, "
        f"95% bootstrap CI {result['paired']['ranker_minus_proposer_ci95_pp']}",
        f"Ranker - KSP-FF: {result['paired']['ranker_minus_ksp_pp']:+.4f} pp, "
        f"95% bootstrap CI {result['paired']['ranker_minus_ksp_ci95_pp']}",
    ])
    (output / "CLOSED_LOOP_RESULTS.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
