# Pure-RMSA Native Common-Future Ceiling

Main trajectory blocking: 0.0000%
Groups: 2

| Continuation | H | Count sensitive | Identity sensitive | Oracle improved groups | Mean block improvement |
|---|---:|---:|---:|---:|---:|
| native_proposer_top1 | 5 | 0.00% | 0.00% | 0.00% | 0.0000 |
| native_proposer_top1 | 10 | 0.00% | 0.00% | 0.00% | 0.0000 |
| ksp_ff_k50_hops | 5 | 0.00% | 0.00% | 0.00% | 0.0000 |
| ksp_ff_k50_hops | 10 | 0.00% | 0.00% | 0.00% | 0.0000 |

**Ranker gate: FAIL**

At max H: non-zero block-count sensitivity, >=5% oracle-improved groups, positive mean oracle improvement
