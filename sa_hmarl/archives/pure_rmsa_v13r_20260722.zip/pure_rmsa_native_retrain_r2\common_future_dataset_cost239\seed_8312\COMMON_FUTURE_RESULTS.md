# Pure-RMSA Native Common-Future Ceiling

Main trajectory blocking: 1.4167%
Groups: 60

| Continuation | H | Count sensitive | Identity sensitive | Oracle improved groups | Mean block improvement |
|---|---:|---:|---:|---:|---:|
| native_proposer_top1 | 20 | 15.00% | 15.00% | 5.00% | 0.0500 |
| native_proposer_top1 | 50 | 35.00% | 36.67% | 10.00% | 0.1000 |
| native_proposer_top1 | 100 | 60.00% | 60.00% | 25.00% | 0.2833 |
| ksp_ff_k50_hops | 20 | 10.00% | 10.00% | 1.67% | 0.0167 |
| ksp_ff_k50_hops | 50 | 30.00% | 30.00% | 6.67% | 0.0667 |
| ksp_ff_k50_hops | 100 | 45.00% | 45.00% | 13.33% | 0.1333 |

**Ranker gate: PASS**

At max H: non-zero block-count sensitivity, >=5% oracle-improved groups, positive mean oracle improvement
