# Pure-RMSA Native Retraining Plan

## Definition lock

This work does not overwrite or rename frozen Strict v1.3. The new method is
called **Pure-RMSA v1.3-R** until every gate below passes.

- Environment: paper-parity pure RMSA; no C-side, MEC, server mask, deadline,
  PPO-C, or DF_C.
- Action space: `K_path=50`, paths sorted by `hops` then km, four paper
  modulations, ten `start_asc` spectrum blocks, at most 2000 flat actions.
- Baselines: `KSP-FF K=50 hops` and `FF-KSP K=50 hops` only.
- Slots: 100. Traffic and request generation are inherited unchanged from
  `pure_rmsa_paper_env.py`.
- Old PPO-R and Ranker checkpoints are transfer baselines only. They are not
  warm starts for the native model.

## Why full retraining is required

The frozen Strict v1.3 proposer and 25-dimensional Ranker were trained under
SA-HMARL C/MEC state, 320 slots, and a different request distribution. The
paper-parity evaluation uses 100 slots and removes C-side state. Retraining
only the Ranker would leave a mismatched Top-30 candidate distribution;
retraining only PPO-R would leave a mismatched Ranker. Both must be rebuilt.

## Overnight stages

### R0 - protocol and parity gate

Re-run one short shared trace and require exact request hashes, legal masks,
action decoding, and canonical KSP-FF/FF-KSP behavior. Baseline blocking must
remain consistent with the completed paper-parity experiment.

### R1 - native proposer warm start

Train a fresh masked `PPOAgentR` actor from pure-RMSA observations. The first
stage uses a multi-positive expert objective over canonical KSP-FF and FF-KSP
actions. This is a supervised warm start, not the final PPO claim. It is used
because sparse future blocking is unsuitable for stable from-scratch PPO.

Report on held-out traces:

- Top-1 exact match to each expert;
- KSP and FF action recall inside proposer Top-30;
- legal-action rate and non-finite checks;
- closed-loop blocking of proposer Top-1;
- Top-30 exact PhiSpec oracle ceiling.

R1 passes when Top-30 recall is at least 95% for either strong expert, no
illegal action is emitted, and proposer Top-1 is no worse than the better
heuristic by more than 1.0 percentage point on the five-seed pilot.

### R2 - native counterfactual Ranker dataset

Run only if R1 passes. For each proposer Top-30 candidate, execute the current
action in an exact environment copy or a separately verified exact temporary
allocation path, then use a shared future request trace. Store one request
group with all candidate features and labels. Pure-RMSA features must not
contain imputed C/MEC fields.

Before training, report Top-30 oracle regret and candidate-level blocking
sensitivity. If the Top-30 oracle does not improve blocking, train an
afterstate-quality Ranker only as an efficiency experiment and do not claim a
blocking objective.

### R3 - Ranker training

Train a fresh listwise Ranker on request-group splits separated by seed. Pick
checkpoints by validation regret, never training loss. Keep PPO-R frozen.

### R4 - five-seed paired pilot

Compare, on identical traces:

1. KSP-FF K=50 hops;
2. FF-KSP K=50 hops;
3. native proposer Top-1;
4. Pure-RMSA v1.3-R (native proposer Top-30 plus native Ranker);
5. Top-30 Oracle as a ceiling, not an online method.

Primary metric: request blocking. Secondary metrics: path hops/km,
modulation, required FS, block start/waste, PhiSpec AUC, decision latency, and
paired action differences. Report paired per-seed deltas and bootstrap 95% CI.

## Stop rules

- Never continue to R2 if R1 recall or legality fails.
- Never claim blocking learning when candidate labels differ only in resource
  efficiency.
- After two failed fixes for the same issue, stop and report the command,
  traceback, both attempted changes, confirmed facts, unverified hypotheses,
  and the exact question requiring user input.
- Independent seed jobs may run in parallel only after one-worker time and
  peak-memory measurement. Use the same batch's workers to improve CPU use.

## Morning deliverables

- `RUN_STATUS.json` with stage completion and failure reason;
- native proposer checkpoint and SHA-256;
- held-out recall/legality report;
- five-seed paired pilot table;
- Oracle ceiling result;
- `NEXT_STEP_DECISION.md` stating GO/STOP for Ranker data generation.

