# Pure-RMSA Native Common-Future Ceiling

Main trajectory blocking: 2.4167%
Groups: 60

| Continuation | H | Count sensitive | Identity sensitive | Oracle improved groups | Mean block improvement |
|---|---:|---:|---:|---:|---:|
| native_proposer_top1 | 20 | 23.33% | 23.33% | 5.00% | 0.0500 |
| native_proposer_top1 | 50 | 43.33% | 43.33% | 13.33% | 0.1333 |
| native_proposer_top1 | 100 | 66.67% | 68.33% | 21.67% | 0.2333 |
| ksp_ff_k50_hops | 20 | 20.00% | 20.00% | 3.33% | 0.0333 |
| ksp_ff_k50_hops | 50 | 43.33% | 43.33% | 6.67% | 0.0667 |
| ksp_ff_k50_hops | 100 | 56.67% | 60.00% | 11.67% | 0.1333 |

**Ranker gate: PASS**

At max H: non-zero block-count sensitivity, >=5% oracle-improved groups, positive mean oracle improvement
