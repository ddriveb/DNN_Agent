# Pure-RMSA Native Common-Future Ceiling

Main trajectory blocking: 1.9000%
Groups: 60

| Continuation | H | Count sensitive | Identity sensitive | Oracle improved groups | Mean block improvement |
|---|---:|---:|---:|---:|---:|
| native_proposer_top1 | 20 | 13.33% | 13.33% | 1.67% | 0.0167 |
| native_proposer_top1 | 50 | 35.00% | 36.67% | 8.33% | 0.0833 |
| native_proposer_top1 | 100 | 60.00% | 61.67% | 23.33% | 0.2667 |
| ksp_ff_k50_hops | 20 | 16.67% | 16.67% | 3.33% | 0.0333 |
| ksp_ff_k50_hops | 50 | 38.33% | 43.33% | 10.00% | 0.1000 |
| ksp_ff_k50_hops | 100 | 53.33% | 61.67% | 16.67% | 0.1833 |

**Ranker gate: PASS**

At max H: non-zero block-count sensitivity, >=5% oracle-improved groups, positive mean oracle improvement
