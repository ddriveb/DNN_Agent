# Pure-RMSA Native Common-Future Ceiling

Main trajectory blocking: 1.8500%
Groups: 60

| Continuation | H | Count sensitive | Identity sensitive | Oracle improved groups | Mean block improvement |
|---|---:|---:|---:|---:|---:|
| native_proposer_top1 | 20 | 21.67% | 23.33% | 5.00% | 0.0500 |
| native_proposer_top1 | 50 | 36.67% | 36.67% | 10.00% | 0.1167 |
| native_proposer_top1 | 100 | 61.67% | 68.33% | 21.67% | 0.2167 |
| ksp_ff_k50_hops | 20 | 26.67% | 28.33% | 0.00% | 0.0000 |
| ksp_ff_k50_hops | 50 | 45.00% | 46.67% | 6.67% | 0.0667 |
| ksp_ff_k50_hops | 100 | 65.00% | 68.33% | 11.67% | 0.1333 |

**Ranker gate: PASS**

At max H: non-zero block-count sensitivity, >=5% oracle-improved groups, positive mean oracle improvement
