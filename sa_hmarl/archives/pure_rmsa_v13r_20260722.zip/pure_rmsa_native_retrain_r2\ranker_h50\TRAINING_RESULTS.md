# Pure-RMSA Native Ranker Training

Selected epoch: 111

| Split | Groups | Sensitive | Model count regret | Deployed count regret | Best hit |
|---|---:|---:|---:|---:|---:|
| train | 360 | 152 | 0.0556 | 0.0778 | 94.72% |
| validation | 60 | 22 | 0.0333 | 0.0167 | 96.67% |
| test | 60 | 19 | 0.0167 | 0.0500 | 98.33% |
