# Pure-RMSA Native Ranker Training

Selected epoch: 61

| Split | Groups | Sensitive | Model count regret | Deployed count regret | Best hit |
|---|---:|---:|---:|---:|---:|
| train | 960 | 173 | 0.0198 | 0.0271 | 98.02% |
| validation | 120 | 26 | 0.0333 | 0.0417 | 96.67% |
| test | 120 | 24 | 0.0250 | 0.0500 | 97.50% |
