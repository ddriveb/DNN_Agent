# Pure-RMSA Native Common-Future Ceiling

Main trajectory blocking: 2.1000%
Groups: 60

| Continuation | H | Count sensitive | Identity sensitive | Oracle improved groups | Mean block improvement |
|---|---:|---:|---:|---:|---:|
| native_proposer_top1 | 20 | 16.67% | 20.00% | 0.00% | 0.0000 |
| native_proposer_top1 | 50 | 35.00% | 38.33% | 8.33% | 0.1000 |
| native_proposer_top1 | 100 | 61.67% | 68.33% | 18.33% | 0.2167 |
| ksp_ff_k50_hops | 20 | 18.33% | 21.67% | 0.00% | 0.0000 |
| ksp_ff_k50_hops | 50 | 35.00% | 38.33% | 6.67% | 0.0667 |
| ksp_ff_k50_hops | 100 | 58.33% | 61.67% | 18.33% | 0.2167 |

**Ranker gate: PASS**

At max H: non-zero block-count sensitivity, >=5% oracle-improved groups, positive mean oracle improvement
