# Pure-RMSA Native Ranker Training

Selected epoch: 141

| Split | Groups | Sensitive | Model count regret | Deployed count regret | Best hit |
|---|---:|---:|---:|---:|---:|
| train | 960 | 398 | 0.0583 | 0.0865 | 94.38% |
| validation | 120 | 49 | 0.0417 | 0.0750 | 95.83% |
| test | 120 | 47 | 0.1083 | 0.1167 | 90.83% |
