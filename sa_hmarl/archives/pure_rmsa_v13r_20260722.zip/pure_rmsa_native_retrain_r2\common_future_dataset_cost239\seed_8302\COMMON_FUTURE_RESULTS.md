# Pure-RMSA Native Common-Future Ceiling

Main trajectory blocking: 2.5333%
Groups: 60

| Continuation | H | Count sensitive | Identity sensitive | Oracle improved groups | Mean block improvement |
|---|---:|---:|---:|---:|---:|
| native_proposer_top1 | 20 | 20.00% | 20.00% | 0.00% | 0.0000 |
| native_proposer_top1 | 50 | 41.67% | 48.33% | 1.67% | 0.0167 |
| native_proposer_top1 | 100 | 65.00% | 70.00% | 11.67% | 0.1500 |
| ksp_ff_k50_hops | 20 | 16.67% | 16.67% | 0.00% | 0.0000 |
| ksp_ff_k50_hops | 50 | 46.67% | 50.00% | 3.33% | 0.0333 |
| ksp_ff_k50_hops | 100 | 61.67% | 70.00% | 11.67% | 0.1500 |

**Ranker gate: PASS**

At max H: non-zero block-count sensitivity, >=5% oracle-improved groups, positive mean oracle improvement
