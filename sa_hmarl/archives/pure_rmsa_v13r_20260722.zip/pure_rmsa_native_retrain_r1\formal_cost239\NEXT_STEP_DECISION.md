# Next Step

GO: generate native Top-30 counterfactual groups and train the native Ranker.
