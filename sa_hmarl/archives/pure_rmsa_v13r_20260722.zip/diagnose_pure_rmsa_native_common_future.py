"""Common-future causal ceiling for the native pure-RMSA proposer Top-30.

The script does not train a network. For each sampled pre-decision state it
executes every proposer Top-30 action in an independent environment branch,
then rolls all branches over the same future request objects. Natural state
divergence is allowed; the exogenous request trace is held fixed.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import torch

from sa_hmarl.agents.ppo_agents import PPOAgentR
from sa_hmarl.baselines.rmsa_baselines import ksp_ff_highest_mod_action
from sa_hmarl.evaluation.pure_rmsa_paper_env import (
    PureRMSAPaperEnv,
    PureRMSARequest,
    generate_paper_requests,
    paper_modulation_registry,
)
from sa_hmarl.training.train_pure_rmsa_native_proposer import (
    TOPOLOGIES,
    _normalize_pad,
)


CONTINUATIONS = ("native_proposer_top1", "ksp_ff_k50_hops")
FEATURE_NAMES = (
    "path_length_norm", "hop_count_norm", "lfb_norm", "path_free_ratio",
    "path_frag", "spectral_efficiency_norm", "reach_norm", "required_fs_norm",
    "block_size_norm", "block_waste", "feasible",
    "path_idx_norm", "mod_idx_norm", "block_idx_norm",
    "bitrate_norm", "holding_norm",
    "pre_occupancy", "pre_free_ratio", "pre_lfb_ratio", "pre_fragmentation",
    "post_occupancy", "post_free_ratio", "post_lfb_ratio", "post_fragmentation",
    "delta_occupancy", "delta_free_ratio", "delta_lfb_ratio", "delta_fragmentation",
)


def _atomic_json(path: Path, payload: Dict[str, Any]) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    os.replace(tmp, path)


def _trace_hash(requests: Sequence[PureRMSARequest]) -> str:
    raw = json.dumps([asdict(req) for req in requests], sort_keys=True).encode()
    return hashlib.sha256(raw).hexdigest()


def _load_agent(checkpoint_path: str) -> PPOAgentR:
    checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
    scale = np.asarray(checkpoint.get("feature_scale"), dtype=np.float32)
    if scale.shape != (11,):
        raise RuntimeError("Native checkpoint is missing the locked 11-D feature scale")
    if checkpoint.get("k_paths") != 50 or checkpoint.get("max_blocks") != 10:
        raise RuntimeError("Native checkpoint action protocol does not match K=50/B=10")
    agent = PPOAgentR(
        input_dim=11,
        mod_registry=paper_modulation_registry(),
        hidden_dims=tuple(checkpoint.get("hidden_dims", (128, 64))),
        device="cpu",
    )
    agent.policy_net.load_state_dict(checkpoint["model_state"])
    agent.policy_net.eval()
    return agent


def _ranked_legal(agent: PPOAgentR, obs: Dict[str, Any], top_k: Optional[int] = None) -> np.ndarray:
    features, mask = _normalize_pad(agent, obs)
    legal = np.flatnonzero(mask)
    if legal.size == 0:
        return np.empty(0, dtype=np.int64)
    with torch.no_grad():
        logits = agent.policy_net(torch.as_tensor(features, dtype=torch.float32)[None]).squeeze(0).cpu().numpy()
    ordered = legal[np.argsort(-logits[legal], kind="stable")]
    if top_k is not None:
        ordered = ordered[: min(int(top_k), len(ordered))]
    return ordered.astype(np.int64)


def _select(agent: PPOAgentR, obs: Dict[str, Any], continuation: str) -> Optional[int]:
    if continuation == "ksp_ff_k50_hops":
        action = ksp_ff_highest_mod_action(obs)
        return None if action is None else int(action)
    if continuation == "native_proposer_top1":
        ranked = _ranked_legal(agent, obs, 1)
        return None if ranked.size == 0 else int(ranked[0])
    raise ValueError(continuation)


def _main_pass(
    agent: PPOAgentR,
    topology: str,
    load: float,
    seed: int,
    warmup: int,
    evaluated: int,
) -> Tuple[List[PureRMSARequest], List[Dict[str, Any]], Dict[str, Any]]:
    env = PureRMSAPaperEnv(TOPOLOGIES[topology], num_slots=100, k_paths=50, max_blocks=10)
    requests = generate_paper_requests(env.num_nodes, seed, warmup + evaluated + 101, load)
    env.reset()
    rows: List[Dict[str, Any]] = []
    blocked = 0
    for index, req in enumerate(requests[: warmup + evaluated]):
        env.advance_time(req.arrival_time)
        obs = env.build_observation(req)
        mask = np.asarray(obs["agent_r_mask"], dtype=bool)
        action = _select(agent, obs, "native_proposer_top1")
        success = False if action is None else bool(env.step(action, obs, req)["success"])
        if index >= warmup:
            blocked += int(not success)
            summary = env.net.spectrum_summary()
            rows.append({
                "request_index": index,
                "legal_actions": int(mask.sum()),
                "legal_ratio": float(mask.mean()) if mask.size else 0.0,
                "occupancy_after": float(summary["occupancy"]),
                "blocked": bool(not success),
                "eligible": bool(action is not None and success),
            })
    return requests, rows, {
        "blocking_rate": blocked / max(evaluated, 1),
        "blocked": blocked,
        "evaluated": evaluated,
        "trace_hash": _trace_hash(requests),
    }


def _spaced(items: Sequence[int], count: int) -> List[int]:
    if not items or count <= 0:
        return []
    if len(items) <= count:
        return list(items)
    positions = np.linspace(0, len(items) - 1, count, dtype=int)
    return [int(items[i]) for i in positions]


def _sample_groups(
    rows: List[Dict[str, Any]],
    per_stratum: int,
    precursor_horizon: int,
    min_candidates: int,
) -> List[Dict[str, Any]]:
    by_index = {int(row["request_index"]): row for row in rows}
    eligible = [
        int(row["request_index"])
        for row in rows
        if row["eligible"] and int(row["legal_actions"]) >= min_candidates
    ]
    blocked_indices = [int(row["request_index"]) for row in rows if row["blocked"]]
    used: set[int] = set()
    selected: List[Dict[str, Any]] = []

    precursor_pool = []
    blocked_array = np.asarray(blocked_indices, dtype=np.int64)
    for index in eligible:
        future = blocked_array[(blocked_array > index) & (blocked_array <= index + precursor_horizon)]
        if future.size:
            precursor_pool.append(index)
    for index in _spaced(precursor_pool, per_stratum):
        used.add(index)
        selected.append({"request_index": index, "stratum": "precursor"})

    pressure_pool = sorted(
        (index for index in eligible if index not in used),
        key=lambda index: (by_index[index]["legal_ratio"], -by_index[index]["occupancy_after"], index),
    )
    for index in pressure_pool[:per_stratum]:
        used.add(index)
        selected.append({"request_index": index, "stratum": "pressure"})

    uniform_pool = [index for index in eligible if index not in used]
    for index in _spaced(uniform_pool, per_stratum):
        used.add(index)
        selected.append({"request_index": index, "stratum": "uniform"})
    return selected


def _capture_snapshots(
    agent: PPOAgentR,
    topology: str,
    requests: Sequence[PureRMSARequest],
    selected: Sequence[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    wanted = {int(item["request_index"]): item["stratum"] for item in selected}
    env = PureRMSAPaperEnv(TOPOLOGIES[topology], num_slots=100, k_paths=50, max_blocks=10)
    env.reset()
    snapshots = []
    max_index = max(wanted, default=-1)
    for index, req in enumerate(requests[: max_index + 1]):
        env.advance_time(req.arrival_time)
        obs = env.build_observation(req)
        action = _select(agent, obs, "native_proposer_top1")
        if index in wanted:
            if action is None:
                raise RuntimeError(f"Selected group {index} unexpectedly has an empty mask")
            candidates = _ranked_legal(agent, obs, 30)
            snapshots.append({
                "request_index": index,
                "stratum": wanted[index],
                "env": copy.deepcopy(env),
                "request": req,
                "future": list(requests[index + 1:index + 101]),
                "deployed_action": int(action),
                "candidates": candidates.tolist(),
            })
        if action is not None:
            result = env.step(action, obs, req)
            if not result["success"]:
                raise RuntimeError(f"Main trajectory action failed at {index}: {result}")
    snapshots.sort(key=lambda item: item["request_index"])
    return snapshots


def _rollout_candidate(
    env_before: PureRMSAPaperEnv,
    current: PureRMSARequest,
    future: Sequence[PureRMSARequest],
    candidate: int,
    continuation: str,
    agent: PPOAgentR,
    horizons: Sequence[int],
    gamma: float,
) -> Dict[str, Any]:
    env = copy.deepcopy(env_before)
    obs = env.build_observation(current)
    first = env.step(int(candidate), obs, current)
    if not first["success"]:
        raise RuntimeError(f"Legal Top-30 candidate failed current execution: {first}")
    blocked_positions: List[int] = []
    blocked_ids: List[int] = []
    for offset, req in enumerate(future[: max(horizons)], start=1):
        env.advance_time(req.arrival_time)
        obs_f = env.build_observation(req)
        action = _select(agent, obs_f, continuation)
        success = False if action is None else bool(env.step(action, obs_f, req)["success"])
        if not success:
            blocked_positions.append(offset)
            blocked_ids.append(int(req.req_id))
    metrics: Dict[str, Any] = {}
    for horizon in horizons:
        positions = [p for p in blocked_positions if p <= horizon]
        ids = [rid for p, rid in zip(blocked_positions, blocked_ids) if p <= horizon]
        metrics[str(horizon)] = {
            "block_count": len(positions),
            "discounted_blocks": float(sum(gamma ** (p - 1) for p in positions)),
            "first_block_time": None if not positions else int(positions[0]),
            "blocked_request_ids": ids,
        }
    return metrics


def _spectrum_vector(env: PureRMSAPaperEnv) -> np.ndarray:
    summary = env.net.spectrum_summary()
    return np.asarray([
        summary["occupancy"], summary["free_ratio"],
        summary["largest_free_block"] / env.num_slots, summary["fragmentation"],
    ], dtype=np.float32)


def _candidate_feature_matrix(
    env: PureRMSAPaperEnv,
    request: PureRMSARequest,
    candidates: Sequence[int],
    agent: PPOAgentR,
) -> np.ndarray:
    obs = env.build_observation(request)
    normalized, mask = _normalize_pad(agent, obs)
    before_links = {edge: slots.copy() for edge, slots in env.net.link_states.items()}
    pre = _spectrum_vector(env)
    rows = []
    num_mods = env.mod_reg.num_formats
    num_paths = max(len(obs["candidate_paths"]), 1)
    for action in candidates:
        action = int(action)
        if not mask[action]:
            raise RuntimeError(f"Feature extraction received illegal candidate {action}")
        path_idx = action // (num_mods * env.max_blocks)
        rem = action % (num_mods * env.max_blocks)
        mod_idx, block_idx = divmod(rem, env.max_blocks)
        path = obs["candidate_paths"][path_idx]
        start, _ = obs["candidate_blocks_per_path_mod"][path_idx][mod_idx][block_idx]
        required = int(obs["required_fs_per_path_mod"][path_idx][mod_idx])
        if not env.net.allocate(path, int(start), required):
            raise RuntimeError("Exact afterstate feature allocation failed")
        post = _spectrum_vector(env)
        env.net.release(path, int(start), required)
        row = np.concatenate([
            normalized[action],
            np.asarray([
                path_idx / max(num_paths - 1, 1),
                mod_idx / max(num_mods - 1, 1),
                block_idx / max(env.max_blocks - 1, 1),
                request.bitrate_gbps / 100.0,
                request.holding_time / 10.0,
            ], dtype=np.float32),
            pre, post, post - pre,
        ])
        rows.append(row)
    for edge, slots in before_links.items():
        if not np.array_equal(slots, env.net.link_states[edge]):
            raise RuntimeError(f"Temporary afterstate feature extraction mutated link {edge}")
    matrix = np.asarray(rows, dtype=np.float32)
    if matrix.shape != (len(candidates), len(FEATURE_NAMES)) or not np.all(np.isfinite(matrix)):
        raise RuntimeError(f"Invalid native Ranker feature matrix {matrix.shape}")
    return matrix


def _group_job(job: Dict[str, Any]) -> Dict[str, Any]:
    os.environ.setdefault("OMP_NUM_THREADS", "1")
    os.environ.setdefault("MKL_NUM_THREADS", "1")
    torch.set_num_threads(1)
    agent = _load_agent(job["checkpoint"])
    snapshot = job["snapshot"]
    candidate_features = _candidate_feature_matrix(
        snapshot["env"], snapshot["request"], snapshot["candidates"], agent
    )
    rows = []
    for continuation in CONTINUATIONS:
        for candidate in snapshot["candidates"]:
            metrics = _rollout_candidate(
                snapshot["env"], snapshot["request"], snapshot["future"],
                candidate, continuation, agent, job["horizons"], job["gamma"],
            )
            rows.append({
                "continuation": continuation,
                "candidate": int(candidate),
                "is_deployed": int(candidate) == int(snapshot["deployed_action"]),
                "metrics": metrics,
            })
    return {
        "request_index": snapshot["request_index"],
        "stratum": snapshot["stratum"],
        "candidate_count": len(snapshot["candidates"]),
        "deployed_action": snapshot["deployed_action"],
        "candidate_features": candidate_features.tolist(),
        "rows": rows,
    }


def _summarize(groups: Sequence[Dict[str, Any]], horizons: Sequence[int]) -> Dict[str, Any]:
    summary: Dict[str, Any] = {}
    for continuation in CONTINUATIONS:
        cont: Dict[str, Any] = {}
        for horizon in horizons:
            sensitive_count = sensitive_discount = sensitive_first = sensitive_identity = 0
            oracle_improvements = []
            deployed_counts = []
            oracle_counts = []
            per_stratum: Dict[str, List[bool]] = {}
            for group in groups:
                rows = [row for row in group["rows"] if row["continuation"] == continuation]
                metrics = [row["metrics"][str(horizon)] for row in rows]
                counts = [int(m["block_count"]) for m in metrics]
                discounts = [float(m["discounted_blocks"]) for m in metrics]
                firsts = [horizon + 1 if m["first_block_time"] is None else int(m["first_block_time"]) for m in metrics]
                identities = [tuple(m["blocked_request_ids"]) for m in metrics]
                deployed_index = next(i for i, row in enumerate(rows) if row["is_deployed"])
                deployed = counts[deployed_index]
                oracle = min(counts)
                is_sensitive = len(set(counts)) > 1 or len(set(identities)) > 1 or len(set(firsts)) > 1
                sensitive_count += int(len(set(counts)) > 1)
                sensitive_discount += int(np.ptp(discounts) > 1e-12)
                sensitive_first += int(len(set(firsts)) > 1)
                sensitive_identity += int(len(set(identities)) > 1)
                oracle_improvements.append(deployed - oracle)
                deployed_counts.append(deployed)
                oracle_counts.append(oracle)
                per_stratum.setdefault(group["stratum"], []).append(is_sensitive)
            n = max(len(groups), 1)
            cont[str(horizon)] = {
                "groups": len(groups),
                "block_count_sensitive_ratio": sensitive_count / n,
                "discounted_block_sensitive_ratio": sensitive_discount / n,
                "first_block_time_sensitive_ratio": sensitive_first / n,
                "blocked_identity_sensitive_ratio": sensitive_identity / n,
                "mean_deployed_block_count": float(np.mean(deployed_counts)),
                "mean_oracle_block_count": float(np.mean(oracle_counts)),
                "mean_oracle_improvement": float(np.mean(oracle_improvements)),
                "oracle_improved_group_ratio": float(np.mean(np.asarray(oracle_improvements) > 0)),
                "sensitivity_by_stratum": {key: float(np.mean(value)) for key, value in per_stratum.items()},
            }
        summary[continuation] = cont
    return summary


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--topology", default="cost239", choices=sorted(TOPOLOGIES))
    parser.add_argument("--load-erlang", type=float, default=600.0)
    parser.add_argument("--seed", type=int, default=8301)
    parser.add_argument("--warmup", type=int, default=500)
    parser.add_argument("--evaluated", type=int, default=6000)
    parser.add_argument("--groups-per-stratum", type=int, default=20)
    parser.add_argument("--precursor-horizon", type=int, default=20)
    parser.add_argument("--min-candidates", type=int, default=5)
    parser.add_argument("--horizons", default="20,50,100")
    parser.add_argument("--gamma", type=float, default=0.99)
    parser.add_argument("--workers", type=int, default=4)
    args = parser.parse_args()

    horizons = sorted({int(x) for x in args.horizons.split(",")})
    if not horizons or max(horizons) > 100:
        raise ValueError("This protocol requires non-empty horizons with max <= 100")
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    status: Dict[str, Any] = {"stage": "main_pass", "started": time.time(), "args": vars(args)}
    _atomic_json(output / "RUN_STATUS.json", status)
    agent = _load_agent(args.checkpoint)
    requests, main_rows, main_summary = _main_pass(
        agent, args.topology, args.load_erlang, args.seed, args.warmup, args.evaluated
    )
    selected = _sample_groups(
        main_rows, args.groups_per_stratum, args.precursor_horizon, args.min_candidates
    )
    snapshots = _capture_snapshots(agent, args.topology, requests, selected)
    if len(snapshots) != len(selected):
        raise RuntimeError(f"Captured {len(snapshots)} snapshots for {len(selected)} selected groups")
    status.update({"stage": "counterfactual", "main_summary": main_summary, "groups": len(snapshots)})
    _atomic_json(output / "RUN_STATUS.json", status)

    jobs = [{
        "checkpoint": args.checkpoint, "snapshot": snapshot,
        "horizons": horizons, "gamma": args.gamma,
    } for snapshot in snapshots]
    groups = []
    with ProcessPoolExecutor(max_workers=max(1, args.workers)) as executor:
        futures = [executor.submit(_group_job, job) for job in jobs]
        for future in as_completed(futures):
            group = future.result()
            groups.append(group)
            print(f"group={group['request_index']} stratum={group['stratum']} candidates={group['candidate_count']}", flush=True)
    groups.sort(key=lambda group: group["request_index"])
    summary = _summarize(groups, horizons)
    gate_metric = summary["native_proposer_top1"][str(max(horizons))]
    gate = bool(
        gate_metric["block_count_sensitive_ratio"] > 0.0
        and gate_metric["oracle_improved_group_ratio"] >= 0.05
        and gate_metric["mean_oracle_improvement"] > 0.0
    )
    result = {
        "protocol": "pure_rmsa_native_common_future_v1",
        "checkpoint": args.checkpoint,
        "main_trajectory": main_summary,
        "sampling": selected,
        "horizons": horizons,
        "continuations": list(CONTINUATIONS),
        "feature_names": list(FEATURE_NAMES),
        "seed": args.seed,
        "summary": summary,
        "groups": groups,
        "ranker_gate_pass": gate,
        "ranker_gate_rule": "At max H: non-zero block-count sensitivity, >=5% oracle-improved groups, positive mean oracle improvement",
    }
    _atomic_json(output / "COMMON_FUTURE_RESULTS.json", result)
    lines = [
        "# Pure-RMSA Native Common-Future Ceiling", "",
        f"Main trajectory blocking: {100*main_summary['blocking_rate']:.4f}%",
        f"Groups: {len(groups)}", "",
        "| Continuation | H | Count sensitive | Identity sensitive | Oracle improved groups | Mean block improvement |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for continuation in CONTINUATIONS:
        for horizon in horizons:
            row = summary[continuation][str(horizon)]
            lines.append(
                f"| {continuation} | {horizon} | {100*row['block_count_sensitive_ratio']:.2f}% | "
                f"{100*row['blocked_identity_sensitive_ratio']:.2f}% | "
                f"{100*row['oracle_improved_group_ratio']:.2f}% | {row['mean_oracle_improvement']:.4f} |"
            )
    lines.extend(["", f"**Ranker gate: {'PASS' if gate else 'FAIL'}**", "", result["ranker_gate_rule"]])
    (output / "COMMON_FUTURE_RESULTS.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    decision = (
        "GO: generate grouped native Ranker data using common-future labels."
        if gate else
        "STOP: Top-30 has no demonstrated common-future blocking ceiling; do not train a blocking Ranker."
    )
    (output / "NEXT_STEP_DECISION.md").write_text(f"# Next Step\n\n{decision}\n", encoding="utf-8")
    status.update({"stage": "complete", "completed": time.time(), "ranker_gate_pass": gate})
    _atomic_json(output / "RUN_STATUS.json", status)


if __name__ == "__main__":
    main()
