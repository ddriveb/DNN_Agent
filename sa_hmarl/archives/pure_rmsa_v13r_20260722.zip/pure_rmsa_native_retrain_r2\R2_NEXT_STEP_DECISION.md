# R2 Common-Future Ranker Decision

## Status

**STOP before closed-loop evaluation. User decision required.**

The causal ceiling passed, but the learned Ranker did not beat the deployed
native proposer consistently on both validation and held-out test seeds.

## Confirmed facts

- Dataset: 8 seeds, 480 request groups, each with at least 5 legal candidates.
- Split: seeds 8301-8306 train, 8307 validation, 8308 untouched test.
- Features: 28 pure-RMSA pre/action/exact-afterstate features; no C/MEC fields.
- Main-trajectory mean blocking: 1.9063%.
- H100 block-count-sensitive groups: 59.38% on average.
- H100 Oracle-improved groups: 19.17% on average.
- H100 mean Oracle improvement: 0.2229 future blocks per sampled group.
- No command raised a traceback and all 8 dataset shards returned exit code 0.

## Attempt 1

Train the locked H100 listwise + SmoothL1 MLP and select by validation
block-count regret.

```powershell
$env:PYTHONPATH='sa_hmarl'
python -m sa_hmarl.training.train_pure_rmsa_native_ranker --dataset-root sa_hmarl/experiments/pure_rmsa_native_retrain_r2/common_future_dataset_cost239 --output-dir sa_hmarl/experiments/pure_rmsa_native_retrain_r2/ranker_h100 --horizon 100 --val-seed 8307 --test-seed 8308 --epochs 200 --lr 0.0003 --temperature 0.1 --reg-weight 1.0 --groups-per-step 16 --seed 42
```

Result: validation regret improved from 0.1000 to 0.0667, but test regret was
unchanged at 0.1333.

## Attempt 2

Run the causally motivated horizon comparison H20/H50/H100 without changing
the feature schema or model architecture.

```powershell
$env:PYTHONPATH='sa_hmarl'
python -m sa_hmarl.training.train_pure_rmsa_native_ranker --dataset-root sa_hmarl/experiments/pure_rmsa_native_retrain_r2/common_future_dataset_cost239 --output-dir sa_hmarl/experiments/pure_rmsa_native_retrain_r2/ranker_h20 --horizon 20 --val-seed 8307 --test-seed 8308 --epochs 120 --lr 0.0003 --temperature 0.1 --reg-weight 1.0 --groups-per-step 16 --seed 42

python -m sa_hmarl.training.train_pure_rmsa_native_ranker --dataset-root sa_hmarl/experiments/pure_rmsa_native_retrain_r2/common_future_dataset_cost239 --output-dir sa_hmarl/experiments/pure_rmsa_native_retrain_r2/ranker_h50 --horizon 50 --val-seed 8307 --test-seed 8308 --epochs 120 --lr 0.0003 --temperature 0.1 --reg-weight 1.0 --groups-per-step 16 --seed 42
```

| Horizon | Validation model/deployed regret | Test model/deployed regret |
|---:|---:|---:|
| 20 | 0.0000 / 0.0000 | 0.0167 / 0.0000 |
| 50 | 0.0333 / 0.0167 | 0.0167 / 0.0500 |
| 100 | 0.0667 / 0.1000 | 0.1333 / 0.1333 |

No horizon improves over deployed on both validation and test.

## Unverified hypotheses

- 480 deliberately stratified groups may be too small for 28-dimensional
  seed-level generalization.
- The scalar utility may discard useful blocked-request identity structure.
- A candidate-independent MLP may not model relative group context well enough.
- The pressure/precursor sampling distribution may differ from online states.

These are hypotheses only. None has been tested, and no third repair should be
attempted without choosing a new protocol.

## Required user decision

Choose one:

1. **Expand data first (recommended):** collect 20 seeds and at least 1,200
   groups, keep the current model and loss fixed, then repeat the seed split.
2. **Stop Ranker work:** retain the native proposer Top-1 result (1.7000% vs
   KSP-FF 1.8767%) as the current method and move to 20-seed/multi-topology
   validation.

Changing architecture or loss now is not recommended because it would mix a
data-size test with an unbounded modeling search.
