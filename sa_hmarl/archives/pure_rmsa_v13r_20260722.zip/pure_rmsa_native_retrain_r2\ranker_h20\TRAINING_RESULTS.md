# Pure-RMSA Native Ranker Training

Selected epoch: 116

| Split | Groups | Sensitive | Model count regret | Deployed count regret | Best hit |
|---|---:|---:|---:|---:|---:|
| train | 360 | 69 | 0.0222 | 0.0278 | 97.78% |
| validation | 60 | 9 | 0.0000 | 0.0000 | 100.00% |
| test | 60 | 10 | 0.0167 | 0.0000 | 98.33% |
