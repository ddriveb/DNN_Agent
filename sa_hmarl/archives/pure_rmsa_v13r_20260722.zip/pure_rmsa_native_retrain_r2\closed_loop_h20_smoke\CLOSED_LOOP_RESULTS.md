# Pure-RMSA Native H20 Ranker Closed Loop

| Method | Blocking | Decision ms | Ranker disagreement |
|---|---:|---:|---:|
| ksp_ff_k50_hops | 0.0000% | 0.012 | 0.00% |
| native_proposer_top1 | 0.0000% | 2.171 | 0.00% |
| native_afterstate_ranker_h20 | 0.0000% | 18.318 | 97.00% |

Ranker - proposer: +0.0000 pp, 95% bootstrap CI [0.0, 0.0]
Ranker - KSP-FF: +0.0000 pp, 95% bootstrap CI [0.0, 0.0]
